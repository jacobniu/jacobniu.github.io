# 跨对话 / 多技能接力协议（借鉴 gstack 产物接力）

目标：上一步把结论**写到磁盘**，下一步（甚至新对话）**先读再干**，不靠聊天记忆。

分诊入口仍是 `android-gstack`；本协议不增加 slash 命令，也不改 `projects/` 硬隔离。

## 目录约定

全部在业务工程下（与技能包隔离）：

```text
projects/<项目名>/
  docs/
    HANDOFF.md      ← 总索引（每个技能结束必须更新）
    SPEC.md         ← android-spec
    DESIGN.md       ← android-design（屏列表 + HTML 路径）
    SCAFFOLD.md     ← android-project-scaffold
    DATA.md         ← android-data-layer
    FEATURE.md      ← android-feature（本轮交付摘要）
    QA.md           ← android-qa
    REVIEW.md       ← android-review
    SHIP.md         ← android-ship
    INVESTIGATE.md  ← android-investigate
  design-preview/   ← HTML 原型（design 技能）
  …                 ← 工程源码（scaffold 及之后）
```

模板见 `.cursor/handoff-templates/`。首次写入时可复制模板再填。

## 每个技能：开头必做

1. 向用户确认或推断 `<项目名>`（对应 `projects/<项目名>/`）。  
2. 若存在 `docs/HANDOFF.md` → **先读**。  
3. 按本技能需要，再读表里「建议先读」的产物；没有也不要编造，缺关键信息报 `NEEDS_CONTEXT`。  
4. 对话里已有用户新指示时，以用户最新说法为准，并回写产物。

## 每个技能：结束必做

1. 写好/更新本技能负责的产物文件。  
2. **更新** `docs/HANDOFF.md`：`last_skill`、`last_status`、`updated`、产物表、`suggested_next`。  
3. 在回复里报完成状态，并给出产物路径（方便人打开核对）。

## 产物 ↔ 技能

| 产物 | 谁写 | 谁应先读 |
|------|------|----------|
| `HANDOFF.md` | 每个技能结束时更新 | 所有技能开头 |
| `SPEC.md` | `android-spec` | design、scaffold、feature、ship |
| `DESIGN.md` + HTML | `android-design` | feature、ui、qa |
| `SCAFFOLD.md` | `android-project-scaffold` | data-layer、feature、ship |
| `DATA.md` | `android-data-layer` | feature、qa |
| `FEATURE.md` | `android-feature` | ui、qa、review |
| `QA.md` | `android-qa` | review、ship、feature（修测出问题） |
| `REVIEW.md` | `android-review` | feature（修 Critical）、ship |
| `SHIP.md` | `android-ship` | 下次发版对照 |
| `INVESTIGATE.md` | `android-investigate` | feature（按根因最小修） |

## 与完成状态的关系

- `DONE` / `DONE_WITH_CONCERNS`：产物与 HANDOFF 必须已落盘（concerns 写进 HANDOFF 的「未收口」）。  
- `NEEDS_CONTEXT` / `BLOCKED`：也要更新 HANDOFF（写明卡在哪），便于下一对话接着问。  

## 不做的事

- 不要求「上一个技能必须 DONE 才能开下一个」；无产物时仍可开干，但要在 HANDOFF 标「未读到 xxx」。  
- 不把接力文件写到技能包根目录。  
- 不在产物里写密钥、密码、token。
