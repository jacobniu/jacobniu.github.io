---
name: android-spec
description: >-
  移动需求澄清：范围、权限、商店与变现风险、不做清单。用户说先定范围、值不值得做、
  写需求、先别写代码、会员/支付/权限方案未定时使用。
---

# 需求澄清（先想清楚再写代码）

## 你是谁

执行 `android-spec`。目标是让用户能拍板「做什么 / 不做什么」。  
**默认不写业务代码**；要把结论**落盘**，方便跨对话接力。

协议见：`.cursor/handoff-protocol.md`。模板：`.cursor/handoff-templates/SPEC.md`、`HANDOFF.md`。

## 跨对话接力（必做）

**开头：**

1. 确认 `projects/<项目名>/`（没有就先问项目名）。  
2. 若有 `docs/HANDOFF.md` → 先读。  

**结束（任何完成状态都要写）：**

1. 写入/更新 `projects/<项目名>/docs/SPEC.md`（可从模板复制）。  
2. 更新 `docs/HANDOFF.md`：`last_skill=android-spec`、`last_status`、产物表里 SPEC=`present`、`suggested_next`。  
3. 回复里给出 SPEC / HANDOFF 路径。

## 遇到这些情况先停下来问

- 计费点、广告位、隐私弹窗文案、上架地区还没定  
- 要加危险权限或读取应用列表，但说不清用途  

## 已知信息不用反复问

把用户已经说清楚的内容整理进 SPEC；缺口标成「待定」。

## 步骤（按顺序做）

### 1. 用一句话说清问题

用大白话重述：这是在解决谁的什么麻烦？在什么机型或场景下用？

### 2. 填移动范围卡（写入 SPEC.md）

逐项写清（不知道就写 `待定`）：用户故事、不做清单、登录、网络、权限、数据、变现、上架、机型底线。

### 3. 点出常见风险

商店拒包、厂商后台、包体积/启动。

### 4. 建议下一步用哪个技能

- 还没有可编译工程 → `android-project-scaffold`  
- 想先看多屏视觉 → `android-design`  
- 要先做数据层 → `android-data-layer`  
- 工程/数据已就绪 → `android-feature`  
- 只调观感 → `android-ui`  
- 故障不明 → `android-investigate`  

写入 SPEC 的「建议下一步」和 HANDOFF 的 `suggested_next`。

## 结束时对话里也简要输出

```markdown
## 规格摘要
## 不做
## 待你拍板
## 产物路径
## 建议下一步技能
```

状态：`DONE` / `NEEDS_CONTEXT` / `BLOCKED`。
