---
name: android-ui
description: >-
  打磨 Jetpack Compose 移动界面：间距、主题、刘海/手势条、字体缩放、暗色。
  在用户说改界面、不好看、对齐设计稿、适配机型观感时使用。不改业务逻辑。
---

# 移动界面打磨

## 0. 身份

只改当前界面相关文件。业务逻辑走 `android-feature`。

## 必须 STOP

- 用户其实在说「点了没反应 / 数据不对」→ 转 feature 或 investigate
- 要引入新 UI 库

## 不要问，直接做

- 颜色/字体走现有 Theme
- 统一当前页间距阶梯，不重做整套 Design System

## 步骤

### Step 1: 看清现状

打开目标 Screen / 组件 / Theme。记下 Material2 还是 3、有无自定义 Spacing。

### Step 2: 移动对照

| 问题 | 优先改法 |
|------|----------|
| 挤成一团 | 间距 4/8/12/16/24，同级一致 |
| 字看不清 | `onSurface` / `onSurfaceVariant` |
| 按钮太花 | 主按钮只有 1 个 |
| 顶进刘海/挖孔 | 用 WindowInsets / 项目已有安全区 |
| 被手势条挡住 | 底部栏/CTA 留出 navigationBars |
| 大字号裁字 | `maxLines` / 可换行，不要写死高度 |
| 暗色翻车 | 查写死的 `Color(0xFF...)` |
| 列表卡顿 | Lazy*；item 里不创建重对象 |

### Step 3: 清单

```
- [ ] 色/字来自 Theme（设计稿指定的色值要注明）
- [ ] 点击区域 ≥ 48.dp
- [ ] 长文案不撑破；系统字体放大可接受
- [ ] 加载/空/错与成功态同一套风格
```

### Step 4: 收尾

说明改了哪些视觉点；无设计稿则列出假设。需要截图时请用户给设计稿或真机图。

STATUS：`DONE` / `DONE_WITH_CONCERNS` / `NEEDS_CONTEXT`。
