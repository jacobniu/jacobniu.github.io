---
name: android-ui
description: >-
  实现层界面打磨：已有 Jetpack Compose 代码上的间距、主题、刘海/手势条、字体缩放、暗色。
  用户说改界面不好看、对齐设计稿或 HTML 原型、适配机型观感时使用。不改业务逻辑；不出 HTML 设计稿。
---

# 界面打磨（改已有 Compose）

## 你是谁

只改**已经存在**的界面代码和资源。  
你是把设计「装进代码」的人，**不是**出设计稿的人。

- 还没有视觉稿、只有参考图 → 先 `android-design`（出 HTML）  
- 点了没反应、数据不对 → `android-feature` 或 `android-investigate`  
- Route / Screen 怎么拆 → 看 `android-feature` 的 `compose-patterns.md`  

改动应在 `projects/<项目名>/` 下。

协议：`.cursor/handoff-protocol.md`。

## 跨对话接力（必做）

**开头：** 读 `HANDOFF.md`；有则读 `DESIGN.md` + HTML、`FEATURE.md`。  
**结束：** 在 `FEATURE.md` 末尾追加「ui 打磨摘要」或更新 HANDOFF 备注；更新 `HANDOFF.md`（`last_skill=android-ui`）。无单独 UI.md，避免文件过多。

## 遇到这些情况先换技能

- 「点了没反应 / 数据不对」→ feature 或 investigate  
- 「先出多屏设计 / HTML」→ `android-design`  
- 要引入新的 UI 库 → 先问用户  

## 可以直接做的

- 颜色、字体跟现有 Theme；有 HTML 或设计稿就对照主色和间距  
- 统一本页间距，不要重做整套设计系统  

## 步骤

### 1. 看清现状

打开目标 Screen、组件、Theme。记下 Material 2 还是 3、有没有自定义间距。  
若有 `projects/.../design-preview/*.html`，先对照再改。

### 2. 常见问题怎么改

| 问题 | 优先做法 |
|------|----------|
| 挤成一团 | 间距用 4/8/12/16/24，同级保持一致 |
| 字看不清 | 用 `onSurface` / `onSurfaceVariant` |
| 按钮太花 | 一页只保留一个主按钮 |
| 顶进刘海 | 用 WindowInsets 或项目已有安全区 |
| 被手势条挡住 | 底部栏留出 navigationBars |
| 大字号裁切 | 可换行，不要写死高度 |
| 暗色发花 | 查写死的 `Color(0xFF...)` |
| 列表卡顿 | 用 Lazy*；item 里少创建临时大对象 |

### 3. 自检

```
- [ ] 颜色和字体来自 Theme（设计稿指定色要注明）
- [ ] 点击区域至少约 48.dp
- [ ] 长文案不撑破；系统字体放大仍能用
- [ ] 加载/空/错与成功态风格统一
```

### 4. 收尾

说明改了哪些视觉点；没有设计稿时写明你做的假设。需要对照图时，请用户给设计稿、HTML 或真机截图。

状态：`DONE` / `DONE_WITH_CONCERNS` / `NEEDS_CONTEXT`。
