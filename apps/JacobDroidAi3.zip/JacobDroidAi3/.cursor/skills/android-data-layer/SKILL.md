---
name: android-data-layer
description: >-
  实现 Android 数据层：Retrofit/OkHttp、DTO 映射、Repository、Room、错误模型、DataStore。
  用户说接接口、写仓库、本地缓存、数据库、分页、仅本地无后端时使用。
  不用于搭工程、画页面、上架发版。
---

# 数据层（网络 / 本地库 / 仓库）

## 什么时候用

接后端接口、做本地库、组装 Repository、划清错误和线程边界。  
也包括 **只有本地、没有后端**（只用 Room / DataStore）。

**不要用本技能做**：搭工程（`android-project-scaffold`）、写页面闭环（`android-feature`）、打磨界面（`android-ui`）、发版（`android-ship`）。

代码应写在 `projects/<项目名>/` 下。

协议：`.cursor/handoff-protocol.md`。模板：`.cursor/handoff-templates/DATA.md`。

## 跨对话接力（必做）

**开头：** 读 `docs/HANDOFF.md`；建议读 `SCAFFOLD.md`、`SPEC.md`（数据与离线约定）。  
**结束：** 写 `docs/DATA.md`，更新 `docs/HANDOFF.md`（`last_skill=android-data-layer`）。

## 先确认再动手

下面二选一说清楚：

- **有后端**：Base URL 从哪来 + 至少一个接口的路径和关键字段；或  
- **仅本地、无网络**：明确声明后，跳过 Retrofit/OkHttp，但仍保留 Repository 接口。

契约不清 → `NEEDS_CONTEXT`，不要编假接口。  
还没有工程骨架 → 先走 `android-project-scaffold`。

## 默认怎么分层

```text
界面 / ViewModel
    ↓
Repository          # 对外唯一入口：领域模型 + Flow/suspend
    ↓
RemoteDataSource    # 有网络时：Retrofit，只处理 DTO
LocalDataSource     # Room / DataStore
    ↓
Mapper              # DTO ↔ 领域模型 ↔ Entity；DTO 不要泄漏到界面
```

- 领域模型放在 `core:model`，或单模块时的 `model` 包。  
- ViewModel 不要直接拿 `FooApi` / `FooDao`。  
- 项目里已有错误类型或 DI 写法 → **照着写**，不要另起一套。  

## 错误怎么表示

项目还没有统一结果类型时，可以用：

```kotlin
sealed interface AppResult<out T> {
    data class Ok<T>(val value: T) : AppResult<T>
    data class Err(val error: AppError) : AppResult<Nothing>
}

sealed interface AppError {
    data object Network : AppError
    data object Unauthorized : AppError
    data class Http(val code: Int) : AppError
    data class Unexpected(val message: String) : AppError
}
```

- 在数据层消化 `IOException` / `HttpException`，不要把 Retrofit 异常直接抛到 Compose。  
- 日志只打状态码、路径、requestId；不要打 token、手机号、完整报文。  

## 有网络时

- OkHttp 日志只开在 Debug；正式包禁止 `BODY`。  
- Retrofit 单例跟项目 DI；序列化跟项目已有方案，不要混两套。  
- Base URL 来自 BuildConfig 或 flavor。  

## Room（含纯本地）

- Entity 和领域模型分开；字段一样也要 Mapper。  
- 持续观察用 `Flow`；一次性操作用 `suspend`。  
- `exportSchema = true`；生产环境不要 `fallbackToDestructiveMigration()`（演示可注明例外）。  
- 主键用稳定 id（如 UUID），不要用会变的标题。  

## Repository

默认「本地为主、远程刷新」。  
纯本地时：`observe()` + 增删改走 LocalDataSource 即可。

## 做完交给谁

交付：API/DTO（若有）、Mapper、Repository；有离线则还有 Entity/DAO/Database；说明错误如何到界面。  
**必须**写入 `docs/DATA.md` 并更新 `docs/HANDOFF.md`。

下一步：写页面 → `android-feature`；只调已有界面 → `android-ui`；还缺视觉稿 → `android-design`。  

细节见 [data-patterns.md](data-patterns.md)。  

状态：`DONE` / `DONE_WITH_CONCERNS` / `BLOCKED` / `NEEDS_CONTEXT`。
