# 数据层写法参考

下面是常用代码形状，按项目现有风格裁剪即可。业务文件写在 `projects/<项目名>/` 下。

## DTO → Domain

```kotlin
@Serializable
data class FooDto(val id: String, val title: String, val updated_at: String?)

data class Foo(val id: String, val title: String, val updatedAt: Instant?)

fun FooDto.toDomain(): Foo = Foo(
    id = id,
    title = title,
    updatedAt = updated_at?.let(Instant::parse),
)
```

字段命名：DTO 跟后端；Domain 用驼峰。禁止在 UI 直接读 `updated_at`。

## Retrofit 接口

```kotlin
interface FooApi {
    @GET("foos")
    suspend fun list(): List<FooDto>
}
```

不要在接口上写 `Call<>`；统一 `suspend`。分页后再上 `PagingSource`，首期列表未要求分页不要提前引入。

## OkHttp Debug 日志

```kotlin
if (BuildConfig.DEBUG) {
    addInterceptor(HttpLoggingInterceptor().apply {
        level = HttpLoggingInterceptor.Level.BASIC
    })
}
```

## Room 迁移

```kotlin
val MIGRATION_1_2 = object : Migration(1, 2) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE foos ADD COLUMN subtitle TEXT")
    }
}
```

新字段必须有默认值或先回填，再提高 `version`。

## DataStore

只存小型偏好（token 引用、开关、主题）。Token 本体优先 `EncryptedSharedPreferences` 或系统账号体系；不要把刷新令牌明文写进普通 DataStore。大批量数据走 Room。
