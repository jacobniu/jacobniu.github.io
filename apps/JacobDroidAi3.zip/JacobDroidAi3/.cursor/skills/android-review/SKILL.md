---
name: android-review
description: >-
  审查移动应用 Kotlin/Compose 改动：正确性、ANR/泄漏、权限隐私、渠道与商店风险。
  用户要求 code review、看 diff、合入前检查时使用。
---

# 合入前审查

## 你是谁

先看 `git diff`（或用户指定的文件）。只报真实问题，不要凑数。  
没有必须修的问题，才能写「建议合」。

审查对象应在 `projects/<项目名>/`（或用户明确指定的范围）。

协议：`.cursor/handoff-protocol.md`。模板：`.cursor/handoff-templates/REVIEW.md`。

## 跨对话接力（必做）

**开头：** 读 `HANDOFF.md`；建议读 `FEATURE.md`、`QA.md`、`SPEC.md`。  
**结束：** 写 `docs/REVIEW.md`，更新 `docs/HANDOFF.md`（`last_skill=android-review`）。发版前建议下游 `android-ship` 先读本文件。

## 可以直接做的

- 对照下面清单过一遍 diff  
- 涉及支付/隐私时，宁可标成警告，并说明拒包或合规风险  

## 怎么做

1. 弄清这次改动目的（新功能 / 修崩溃 / 重构）。  
2. 按下表检查。  
3. 按严重程度输出。  

## 检查清单

### 架构

- [ ] 界面没有直接调 API/DAO  
- [ ] ViewModel 没有乱持有 Activity Context  
- [ ] Screen 可预览，或符合项目旧习惯；主页面最好有 Preview  
- [ ] 模块依赖方向正确（feature 之间不互依）  

### 正确性与生命周期

- [ ] 空指针、未处理异常  
- [ ] 页面销毁后仍回调；进程被杀后关键状态是否合理  
- [ ] 加载 / 空 / 错误有处理；拒绝权限、登录过期、空列表不白屏  

### 性能与稳定

- [ ] 主线程读写磁盘/网络（有 ANR 风险）  
- [ ] Compose 参数不稳定导致乱重组；列表缺少稳定 `key`  
- [ ] 大图未压缩；ViewModel/单例持有 Activity Context  
- [ ] 监听未注销；新增长驻服务/保活是否必要  

### 安全、隐私、商店

- [ ] 没有密钥/密码进仓库  
- [ ] 日志不泄露 Token/手机号/精确位置；正式包无 BODY 日志  
- [ ] 没有明文 HTTP、没有信任所有证书  
- [ ] 新增危险权限有必要且用途说得清  
- [ ] 混淆后反射/序列化是否缺 keep（若本次相关）  

### 工程与渠道

- [ ] 没有无关文件、多余依赖  
- [ ] flavor / 包名 / 应用名 / 签名没有被误改  
- [ ] 相关模块尽量能编译（环境允许就跑一次 assemble）  
- [ ] 业务文件仍在 `projects/` 下，没有写回技能包根目录  

## 输出格式

```markdown
## 结论
建议合 / 修完再合 / 不能合

## 必须修（Critical）
- 文件:行号 — 问题 — 建议改法

## 建议改（Warning）
## 可选（Nit）
## 做得好的地方
```

有阻断需改代码时，指到对应技能，并保证 REVIEW.md 已落盘。要上架 → `android-ship`（应先读 REVIEW）。  
支付/隐私相关不要只写成 Nit。
