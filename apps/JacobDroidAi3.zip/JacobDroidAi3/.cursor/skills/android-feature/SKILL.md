---
name: android-feature
description: >-
  用 Kotlin + Jetpack Compose 实现移动功能（Screen、ViewModel、Repository）。
  用户要求加页面、写功能、改逻辑、已知原因后修 bug 时使用。闪退/ANR 根因未明时不要用本技能。
---

# 功能开发（页面 + 逻辑）

## 你是谁

把用户要的功能做到「真机/模拟器上可以按步骤验证」，或明确报 `BLOCKED`。  
不要顺手重构无关模块。业务代码写在 `projects/<项目名>/` 下。

协议：`.cursor/handoff-protocol.md`。模板：`.cursor/handoff-templates/FEATURE.md`。

## 跨对话接力（必做）

**开头：**

1. 读 `docs/HANDOFF.md`。  
2. 有则读：`SPEC.md`、`DESIGN.md`（+ HTML）、`DATA.md`、`SCAFFOLD.md`、`INVESTIGATE.md`（若本轮是按根因修）。  
3. 没有 SPEC/DESIGN 也可做，但在 FEATURE/HANDOFF 标明「未读到 xxx」，范围过大则转 `android-spec` / `android-design`。  

**结束：** 写 `docs/FEATURE.md`，更新 `docs/HANDOFF.md`（`last_skill=android-feature`）。

开始前先看要不要换技能：

- 还没有工程 / 要新建模块结构 → 先 `android-project-scaffold`  
- 范围、计费、权限政策不清 → 先 `android-spec`  
- 只有参考图、界面结构还没有 → 可先 `android-design` 出 HTML  
- 闪退/ANR/偶现且原因不明 → 先 `android-investigate`  
- 需要新建 API/Room/Repository 且没有现成写法 → 先 `android-data-layer`（或本轮约定先数据后界面）  

## 遇到这些情况先停

- 要改 `applicationId` / `minSdk` / `targetSdk` / 签名  
- 要新加危险权限或支付/广告 SDK  
- 产品规则不清（会员权益、价格、是否强制登录）  
- 页面既没有 Repository，也没说「先用假数据/内存」  

## 已知惯例可以直接做

- 按项目命名新建 Screen / ViewModel（优先 Route + Screen，见 [compose-patterns.md](compose-patterns.md)）  
- 补上加载中 / 空 / 错 / 弱网（项目已有习惯就跟项目）  
- 文案走 string 资源（项目已这样要求时）  

## 步骤（按顺序做）

### 0. 确认本轮范围

一句话说清交付物。超过「一个页面或一个闭环」且没有规格 → 停下或转 `android-spec`。

### 1. 摸清现状

- 工程必须在 `projects/<项目名>/`；若还在技能包根目录 → 先迁过去或用 scaffold 重建。  
- 搜同类 Screen / ViewModel / Repository / 导航。  
- 看清模块、包名、DI（Hilt / Koin / 手动），**照着写**。  
- 复用现有导航、权限封装、错误提示，不要另造一套。  

### 2. 按层落地

```
XxxRoute（取 ViewModel，收集状态，把事件用 lambda 传给 Screen）
  → XxxScreen（只收 state 和事件；便于 Preview）
  → XxxViewModel（viewModelScope；关键恢复用 SavedStateHandle 或项目写法）
  → 复杂业务再加 XxxUseCase
  → XxxRepository（已有就复用；新建跟 data-layer 约定）
  → 网络 / Room / DataStore
```

- 新文件放对应 feature 包。  
- `UiState` 用不可变 `data class`；一次性事件跟项目（`SharedFlow` / `Channel`）。  
- Screen 不拿 ViewModel、不打网络、不读 Repository。  
- 不要在 `@Composable` 里做网络或读库。  

### 3. 自检清单

```
- [ ] 命名和包结构跟现有项目一致
- [ ] Route / Screen 已分开（或跟项目旧习惯一致）
- [ ] ViewModel 不持有 Activity Context
- [ ] 耗时操作在后台；界面只观察状态
- [ ] 加载中 / 空 / 错 / 弱网有表现
- [ ] 拒绝权限、登录过期有降级，不白屏
- [ ] 回前台、配置变更后关键信息不丢（按需要）
- [ ] 主页面或关键组件有 Preview（优先空/错/加载）
- [ ] 文案走 string；没有乱加依赖
- [ ] 没有擅自加支付/广告/危险权限；日志无 Token/手机号
- [ ] 会请求网络时，失败提示用户能看懂
```

### 4. 收尾

- 列出改了哪些文件；说明怎么挂到导航。  
- 写清真机怎么验（写入 FEATURE.md）。  
- **落盘** `docs/FEATURE.md` + 更新 `docs/HANDOFF.md`。  
- 缺 API/密钥 → `NEEDS_CONTEXT`。  
- 接下来：要测 → `android-qa`；要审查 → `android-review`；只调观感 → `android-ui`。  

## 禁止

- 为了「更优雅」重写整层架构；密钥进代码；Composable 里直接请求网络。  
- 新开前台服务硬扛厂商杀后台（除非任务就是这个且用户确认）。  

页面写法细节见 [compose-patterns.md](compose-patterns.md)。  

状态：`DONE` / `DONE_WITH_CONCERNS` / `BLOCKED` / `NEEDS_CONTEXT`。
