---
name: android-feature
description: >-
  用 Kotlin + Jetpack Compose 实现移动功能（Screen、ViewModel、Repository）。
  在用户要求加页面、写功能、改逻辑、已知原因后修 bug 时使用。闪退/ANR 根因未明时不要用本技能。
---

# 移动功能开发

## 0. 身份

实现用户要的功能，直到可在真机/模拟器上按步骤验证，或明确 `BLOCKED`。禁止顺手重构无关模块。

范围、计费、权限政策不清 → **先调用 `android-spec`**，不要开写。  
闪退/ANR/偶现且根因不明 → **先调用 `android-investigate`**。

## 必须 STOP

- 改 `applicationId` / `minSdk` / `targetSdk` / 签名
- 新增危险权限或支付/广告 SDK
- 产品规则不清（会员权益、价格、是否强制登录）

## 不要问，直接做

- 按现有命名新建 Screen / ViewModel
- 补加载中 / 空 / 错 / 弱网 四种状态（项目已有惯例则跟项目）
- 文案走 string 资源（项目已有该习惯时）

## 步骤（禁止跳步）

### Step 0: 范围

一句话确认本轮交付。超过「一个页面或一个闭环」且用户没给规格 → STOP 或转 `android-spec`。

### Step 1: 摸清现状

- 搜同类 Screen / ViewModel / Repository / 导航图。
- 看清模块、包名、DI（Hilt / Koin / 手动），**照着写**。
- 看清现有导航、权限封装、网络错误展示，复用不要新造。

### Step 2: 分层落地

```
XxxScreen（Compose，只收集 State / 发 Event）
  → XxxViewModel（viewModelScope；关键恢复用 SavedStateHandle 或项目写法）
  → 复杂业务才加 XxxUseCase
  → XxxRepository
  → 网络 / Room / DataStore
```

- 新文件放对应 feature 包。
- `UiState` 用不可变 `data class`；一次性事件跟项目（`SharedFlow` / `Channel`）。
- 不要在 `@Composable` 里打网络或读库。

### Step 3: 移动检查清单

```
- [ ] 沿用现有命名与包结构
- [ ] ViewModel 不持有 Activity Context
- [ ] IO 在后台；UI 只观察 State
- [ ] 加载中 / 空 / 错 / 弱网（或超时）有表现
- [ ] 权限拒绝、登录过期有降级，不白屏
- [ ] 从后台回前台、配置变更后关键信息不丢（按页面需要）
- [ ] 文案走 string；未引入无关依赖
```

### Step 4: 收尾

- 列出改动文件。
- 写清真机验证：装哪、点哪、断网/拒权限时期望看到什么。
- 缺 API/密钥 → `NEEDS_CONTEXT`。
- 用户要求可测时，建议接着调用 `android-qa`。

## 禁止

- 为优雅重写整层架构；密钥进代码；Composable 里直接请求网络。
- 新开前台服务硬抗厂商杀后台（除非任务就是这个且用户确认）。

STATUS：`DONE` / `DONE_WITH_CONCERNS` / `BLOCKED` / `NEEDS_CONTEXT`。
