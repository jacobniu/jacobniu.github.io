# Compose 页面写法参考

做功能页时，优先把 **Route** 和 **Screen** 分开：Route 负责拿 ViewModel，Screen 只负责展示，方便预览。  
只调间距、主题时走 `android-ui`，不要在这里改业务逻辑。

## Route 包装（可预览的关键）

```kotlin
@Composable
fun FooRoute(
    onBack: () -> Unit,
    onOpenDetail: (String) -> Unit,
    viewModel: FooViewModel = hiltViewModel(),
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    FooScreen(
        state = state,
        onBack = onBack,
        onRetry = { viewModel.onEvent(FooEvent.Retry) },
        onClickItem = onOpenDetail,
    )
}

@Composable
fun FooScreen(
    state: FooUiState,
    onBack: () -> Unit,
    onRetry: () -> Unit,
    onClickItem: (String) -> Unit,
    modifier: Modifier = Modifier,
) { /* 只读 state */ }
```

项目若用 Koin / 手动 DI，把 `hiltViewModel()` 换成项目既有取 VM 方式即可。

## UiState / Event

```kotlin
data class FooUiState(
    val isLoading: Boolean = false,
    val items: List<FooItem> = emptyList(),
    val errorMessage: String? = null,
)

sealed interface FooEvent {
    data object Retry : FooEvent
    data class ClickItem(val id: String) : FooEvent
}
```

Snackbar 等一次性提示用 `Channel`/`SharedFlow`，勿长期塞在 UiState 里忘清。

## 列表项

```kotlin
LazyColumn(modifier = modifier) {
    items(state.items, key = { it.id }) { item ->
        FooRow(item = item, onClick = { onClickItem(item.id) })
    }
}
```

## 状态分支

```kotlin
when {
    state.isLoading && state.items.isEmpty() -> FooLoading()
    state.errorMessage != null && state.items.isEmpty() -> FooError(state.errorMessage, onRetry)
    state.items.isEmpty() -> FooEmpty()
    else -> FooList(state.items, onClickItem)
}
```

有缓存数据时允许列表上叠加载，不要整页挡住已有内容（下拉刷新除外）。

## 反例

```kotlin
// 禁止：Screen 内直接打 Retrofit
@Composable
fun FooScreen() {
    val items = remember { mutableStateListOf<Foo>() }
    LaunchedEffect(Unit) { items += api.getFoo() }
}
```

```kotlin
// 禁止：无 key 的长列表
Column { foos.forEach { FooRow(it) } }
```
