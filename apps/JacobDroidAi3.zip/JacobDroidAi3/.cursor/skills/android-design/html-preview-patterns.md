# HTML 多屏预览参考

做一个**自包含**的 HTML：样式和脚本都写在同一个文件里，不要依赖外网 CDN。  
生成时按真实业务改文案和区块，不要原样塞假登录凑数。

```html
<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>流程预览</title>
  <style>
    :root {
      --bg: #0f1115;
      --panel: #1a1d24;
      --card: #ffffff;
      --text: #111827;
      --muted: #6b7280;
      --accent: #2563eb;
      --phone-w: 390px;
      --phone-h: 844px;
    }
    * { box-sizing: border-box; }
    body {
      margin: 0; font-family: "Segoe UI", "PingFang SC", sans-serif;
      background: var(--bg); color: #e5e7eb;
    }
    header, footer { padding: 16px 24px; }
    footer { color: #9ca3af; font-size: 12px; }
    .layout { display: flex; gap: 24px; padding: 0 24px 32px; align-items: flex-start; }
    nav {
      min-width: 180px; background: var(--panel); border-radius: 12px; padding: 12px;
    }
    nav button {
      display: block; width: 100%; text-align: left; margin: 6px 0; padding: 10px 12px;
      border: 0; border-radius: 8px; background: transparent; color: #e5e7eb; cursor: pointer;
    }
    nav button.active, nav button:hover { background: #2a3140; }
    .phones { display: flex; flex-wrap: wrap; gap: 20px; }
    .phone {
      width: var(--phone-w); height: var(--phone-h); background: var(--card); color: var(--text);
      border-radius: 28px; overflow: hidden; box-shadow: 0 12px 40px rgba(0,0,0,.35);
      display: none; flex-direction: column;
    }
    .phone.active { display: flex; }
    .status { height: 48px; padding: 14px 20px 0; font-size: 14px; font-weight: 600; }
    .content { flex: 1; padding: 8px 20px 20px; overflow: auto; }
    .btn {
      display: block; width: 100%; margin-top: 12px; padding: 14px; border: 0; border-radius: 12px;
      background: var(--accent); color: #fff; font-size: 16px; cursor: pointer;
    }
    .muted { color: var(--muted); font-size: 13px; }
    .chip { display: inline-block; padding: 2px 8px; border-radius: 999px; background: #eef2ff; color: #3730a3; font-size: 11px; }
  </style>
</head>
<body>
  <header>
    <strong>示例流程预览</strong>
    <span class="muted"> — 屏：列表 / 详情（可点跳转）</span>
  </header>
  <div class="layout">
    <nav id="nav">
      <button type="button" data-go="list" class="active">1. 列表</button>
      <button type="button" data-go="detail">2. 详情</button>
    </nav>
    <div class="phones">
      <section class="phone active" id="screen-list" aria-label="列表">
        <div class="status">列表 <span class="chip">主路径</span></div>
        <div class="content">
          <p class="muted">示意列表项</p>
          <button type="button" class="btn" data-go="detail">打开详情</button>
        </div>
      </section>
      <section class="phone" id="screen-detail" aria-label="详情">
        <div class="status">详情</div>
        <div class="content">
          <p>详情正文示意</p>
          <button type="button" class="btn" data-go="list">返回列表</button>
        </div>
      </section>
    </div>
  </div>
  <footer>
    视觉/交互原型，非商店截图定稿。实现请使用 android-feature / android-ui。
  </footer>
  <script>
    function show(id) {
      document.querySelectorAll(".phone").forEach(function (el) {
        el.classList.toggle("active", el.id === "screen-" + id);
      });
      document.querySelectorAll("nav button").forEach(function (btn) {
        btn.classList.toggle("active", btn.getAttribute("data-go") === id);
      });
    }
    document.querySelectorAll("[data-go]").forEach(function (el) {
      el.addEventListener("click", function () { show(el.getAttribute("data-go")); });
    });
  </script>
</body>
</html>
```

## 多屏并排（可选）

若用户要「一屏看全」，可让多个 `.phone` 同时 `display:flex`，仍保留 `data-go` 高亮当前焦点屏。
