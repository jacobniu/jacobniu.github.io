---
name: android-investigate
description: >-
  移动故障调查：闪退、ANR、卡死、偶现、杀进程后异常。用户说崩溃、ANR、
  线上只复现、为什么坏了、先查根因时使用。根因未明之前不要大改代码。
---

# 故障调查（先查清再改）

## 你是谁

先找出原因，再提最小改法。不要一上来重写页面，也不要「顺便重构」。

业务代码在 `projects/<项目名>/` 下排查。

协议：`.cursor/handoff-protocol.md`。模板：`.cursor/handoff-templates/INVESTIGATE.md`。

## 跨对话接力（必做）

**开头：** 读 `HANDOFF.md`；建议读 `FEATURE.md`、上次 `INVESTIGATE.md`。  
**结束：** 写 `docs/INVESTIGATE.md`，更新 `docs/HANDOFF.md`。用户同意修复后，`android-feature` 应先读本文件。

## 遇到这些情况先停

- 既没有复现步骤，也没有日志/堆栈/缺陷单 → 列出你需要的材料，报 `NEEDS_CONTEXT`  
- 修复会动到支付校验、签名、权限模型 → 先问用户  

## 可以直接做的

- 先搜项目里有没有同类崩溃处理、日志工具、已有缺陷  
- 堆栈能对上仓库代码时，先读相关代码再下结论  

## 步骤（按顺序做）

### 1. 固定现场

尽量收齐：

```
- 现象：闪退 / ANR / 白屏 / 数据错 / 点了没反应
- 机型、系统版本、渠道包、App 版本（versionName / versionCode）
- 必现还是偶现；冷启动还是从后台回来
- 网络：Wi-Fi / 蜂窝 / 弱网 / 切换
- 材料：logcat、崩溃平台、ANR traces、截图
```

缺关键信息就写进 `NEEDS_CONTEXT`，不要编堆栈。

### 2. 判断方向

可以多选，但要排出主次：

- 崩溃：空指针、未捕获异常、JNI、混淆缺 keep  
- ANR：主线程读写、锁、长时间同步  
- 生命周期：页面销毁后还回调、进程被杀、配置变更  
- 厂商后台：进程被杀、推送收不到、自启动被拒  
- 资源：内存吃紧、大图、泄漏  
- 业务数据：接口、本地库损坏、登录态  

### 3. 根因一句话

写清：**什么操作触发 → 哪段代码或哪条链路 → 为什么用户会看到这个现象**。  
证据不够就标明「猜测」，不要写成定论。

### 4. 最小修复建议

- 只列最小改动范围；用户同意动手后再转 `android-feature`。  
- 建议回归：同机型、杀进程、弱网各走一遍。  

### 可选：冻结目录

定位到模块后，写一行路径到：

```text
.cursor/state/freeze-dir.txt
```

例如：`projects/TodoApp/app/src/main/`（必须在 `projects/<项目名>/` 下，不要冻技能包根目录）。

`check_android_freeze.py` 会拦住范围外的写入。解除：删掉该文件，或用户说「解除冻结」后删除。

## 结束时这样输出

```markdown
## 现象
## 根因（或最大嫌疑）
## 证据
## 建议改动（最小）
## 建议回归（真机步骤）
## 落盘：docs/INVESTIGATE.md + docs/HANDOFF.md
```

状态：`DONE` / `DONE_WITH_CONCERNS` / `NEEDS_CONTEXT` / `BLOCKED`。
