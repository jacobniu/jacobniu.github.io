---
name: android-project-scaffold
description: >-
  从 0 在 projects/ 下落盘可编译的 Android 模板工程，或扩展模块/Gradle 骨架（Hilt、Compose、Version Catalog）。
  用户说新建项目、创建模板工程、初始化骨架、加 feature 模块、配 AGP/Gradle 时使用。
  不用于画页面业务、写具体 Repository、出 HTML 设计稿、上架发版。
---

# 项目脚手架（写成可编译工程）

## 你是谁

你要把工程**真正写到磁盘上**，而不是只告诉用户「去 Android Studio 点新建」。  

成功标准：文件落在 **`projects/<项目名>/`**，用户本机尽量能跑 Gradle 组装；并写好 **SCAFFOLD.md + HANDOFF.md** 供跨对话接力。  
若缺 JDK/SDK，标 `DONE_WITH_CONCERNS`，并写明缺什么。

协议：`.cursor/handoff-protocol.md`。模板：`.cursor/handoff-templates/SCAFFOLD.md`。

## 跨对话接力（必做）

**开头：** 读 `docs/HANDOFF.md`、若有则读 `docs/SPEC.md`（包名/模块偏好）。  
**结束：** 写 `docs/SCAFFOLD.md`，更新 `docs/HANDOFF.md`（`last_skill=android-project-scaffold`）。

**硬性规则**：业务工程不能写在技能包根目录。根目录留给 `.cursor/`、`AGENTS.md` 等。违规路径会被 Hook 拦截。

**不要用本技能做**：接接口（`android-data-layer`）、写业务页（`android-feature`）、出 HTML 设计（`android-design`）、打磨界面（`android-ui`）、发版（`android-ship`）。  
产品范围没定清楚 → 先 `android-spec`。

## 先问清楚再动手

缺 **项目名 + applicationId + 包名** 时，先问一句。其余用下面默认值。  
落盘根目录固定：`projects/<项目名>/`（项目名用用户给的名字，去掉空格）。

用户指定了别的技术栈（如 Koin、XML）→ 跟用户，并在文件头注释说明为何偏离默认。

## 预设（没指定就问一句）

| 预设 | 什么时候用 | 模块 |
|------|------------|------|
| `demo-single` | 演示、TODO、验证本技能包 | 只有 `:app` |
| `commercial-multi` | 正式商业应用、后面会变大 | `:app` + `core:*` + 空的 feature 入口 |

## 默认技术栈

| 项 | 默认 |
|----|------|
| 语言 / 界面 | Kotlin，Jetpack Compose，Material3 |
| 架构 | 界面 → ViewModel → Domain（可选）→ Repository → 数据源 |
| 依赖注入 / 异步 | Hilt，协程 + Flow |
| 构建 | Gradle Kotlin DSL + Version Catalog |
| 导航 / 偏好 | Navigation Compose，DataStore |
| SDK | `minSdk 26`；compile/target 用当前稳定版写进 Catalog |

## 工作步骤（必须写成文件）

```
- [ ] 1. 确认预设：demo-single 或 commercial-multi
- [ ] 2. 确认目录：projects/<项目名>/（勿占用 reserved 名 `backup`）
- [ ] 3. 画出模块关系和包名
- [ ] 4. 写入 Catalog、settings、各模块 build 脚本、gradle wrapper（见下方 Wrapper 策略）
- [ ] 5. 写入 Application、Hilt、主题、导航宿主、AndroidManifest
- [ ] 6. 写入该工程自己的 .gitignore（含 local.properties、密钥文件）
- [ ] 7. feature 只留空入口，不要造假登录、假列表
- [ ] 8. 在该目录尝试 ./gradlew :app:assembleDebug（能跑就跑，不能就说明原因）
```

### Gradle Wrapper 策略（强制）

**不要**从公网临时下载 `gradle-wrapper.jar`，也**不要**手写/生成一套与备份不一致的 `gradlew` / `gradlew.bat`。

权威副本均在 `projects/backup/`（共享资产，不是业务 App）：

| 备份文件 | 复制到 |
|----------|--------|
| `gradle-wrapper.jar` | `projects/<项目名>/gradle/wrapper/gradle-wrapper.jar` |
| `gradlew` | `projects/<项目名>/gradlew`（复制后 `chmod +x`） |
| `gradlew.bat` | `projects/<项目名>/gradlew.bat` |

步骤：

1. 搭每个新工程时，**整份复制**上表三件（Agent 用 `cp`，禁止 curl 下 jar、禁止自创精简版 gradlew）。  
2. 另写 `gradle/wrapper/gradle-wrapper.properties`（`distributionUrl` 须与备份 jar 兼容的 Gradle 版本）。  
3. 若 `projects/backup/` 缺上述任一文件 → `BLOCKED`，提示用户补齐备份后再继续；禁止改去外网拉文件顶替（内网/合规环境）。

细节见 [gradle-defaults.md](gradle-defaults.md)「Gradle Wrapper」。

### 至少要写出这些文件（都在 `projects/<项目名>/` 下）

对照 [gradle-defaults.md](gradle-defaults.md)、[module-layout.md](module-layout.md)：

- `settings.gradle.kts`、工程根 `build.gradle.kts`、`gradle.properties`  
- `gradle/libs.versions.toml`  
- `app/build.gradle.kts`  
- `app/src/main/AndroidManifest.xml`  
- Application、MainActivity、主题、导航入口  
- 该工程目录内的 `.gitignore`  
- `gradle/wrapper/gradle-wrapper.jar` + 工程根 `gradlew` / `gradlew.bat`（均 **从 `projects/backup/` 复制**）+ 自写 `gradle-wrapper.properties`

`commercial-multi` 还要有：`core/model|common|network|database`，以及一个空的 `feature/<name>` 壳。

### 生成时注意

- 不要只回复步骤让用户手建（用户明确只要说明时除外）。  
- 不要把工程写到技能包根目录。  
- 不要塞假业务页面。  
- 正式包混淆交给 `android-ship`；这里 release 可先关 minify。  
- 仓库源只用 `google()` + `mavenCentral()`（或用户给的合规内部源）。  
- `projects/backup/` 只放脚手架共享资产，**禁止**当成业务项目名或往里写 App 源码。  

## 做完怎么交接

1. 写入 `docs/SCAFFOLD.md` 并更新 `docs/HANDOFF.md`  
2. 预设与模块怎么拆（一句话）  
3. 工程路径与 Application / Activity  
4. 打开方式：Android Studio 打开 **`projects/<项目名>/`**，或该目录 `./gradlew :app:assembleDebug`  
5. 下一步：`android-spec` / `android-design` / `android-data-layer` / `android-feature`（写入 HANDOFF.`suggested_next`）

状态：`DONE` / `DONE_WITH_CONCERNS` / `BLOCKED` / `NEEDS_CONTEXT`。
