# Gradle 默认模板

版本号只放在 Version Catalog 里，模块通过 alias 引用。  
具体版本号以创建当天的稳定版为准，写进 `libs.versions.toml` 后，不要再在别处抄一份当真理。  
这些文件应生成在 `projects/<项目名>/` 下。

## `gradle/libs.versions.toml` 必有 alias

```toml
[versions]
agp = "…"
kotlin = "…"
composeBom = "…"
hilt = "…"
ksp = "…"
retrofit = "…"
okhttp = "…"
room = "…"

[libraries]
androidx-compose-bom = { group = "androidx.compose", name = "compose-bom", version.ref = "composeBom" }
androidx-compose-ui = { group = "androidx.compose.ui", name = "ui" }
androidx-compose-material3 = { group = "androidx.compose.material3", name = "material3" }
androidx-compose-ui-tooling-preview = { group = "androidx.compose.ui", name = "ui-tooling-preview" }
androidx-lifecycle-viewmodel-compose = { group = "androidx.lifecycle", name = "lifecycle-viewmodel-compose" }
androidx-navigation-compose = { group = "androidx.navigation", name = "navigation-compose" }
androidx-hilt-navigation-compose = { group = "androidx.hilt", name = "hilt-navigation-compose" }
hilt-android = { group = "com.google.dagger", name = "hilt-android", version.ref = "hilt" }
hilt-compiler = { group = "com.google.dagger", name = "hilt-compiler", version.ref = "hilt" }
retrofit = { group = "com.squareup.retrofit2", name = "retrofit", version.ref = "retrofit" }
okhttp-logging = { group = "com.squareup.okhttp3", name = "logging-interceptor" }
room-runtime = { group = "androidx.room", name = "room-runtime", version.ref = "room" }
room-ktx = { group = "androidx.room", name = "room-ktx", version.ref = "room" }
room-compiler = { group = "androidx.room", name = "room-compiler", version.ref = "room" }

[plugins]
android-application = { id = "com.android.application", version.ref = "agp" }
android-library = { id = "com.android.library", version.ref = "agp" }
kotlin-android = { id = "org.jetbrains.kotlin.android", version.ref = "kotlin" }
kotlin-compose = { id = "org.jetbrains.kotlin.plugin.compose", version.ref = "kotlin" }
hilt = { id = "com.google.dagger.hilt.android", version.ref = "hilt" }
ksp = { id = "com.google.devtools.ksp", version.ref = "ksp" }
```

`app` 模块启用：`android.application`、`kotlin.android`、`kotlin.compose`、`hilt`、`ksp`。  
`core` / `feature` 库模块用 `android.library` 替换 `android.application`。

## `:app` build 要点

```kotlin
android {
    namespace = "<applicationId>"
    compileSdk = libs.versions.compileSdk.get().toInt()
    defaultConfig {
        applicationId = "<applicationId>"
        minSdk = 26
        targetSdk = libs.versions.targetSdk.get().toInt()
        versionCode = 1
        versionName = "0.1.0"
    }
    buildFeatures { compose = true }
    buildTypes {
        release {
            isMinifyEnabled = false // 上架前由 android-ship 打开
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro",
            )
        }
        debug { isMinifyEnabled = false }
    }
}
```

`compileSdk` / `targetSdk` 若 Catalog 尚未建数字条目，可在模块里写当前稳定整数，但同一仓库只允许一个来源。

## Gradle Wrapper

权威副本（全技能包共用，后续项目一律从这里复制，不要手写精简脚本、不要 curl 下 jar）：

```text
projects/backup/gradle-wrapper.jar
projects/backup/gradlew
projects/backup/gradlew.bat
```

新工程落盘时执行等价操作：

```bash
mkdir -p projects/<项目名>/gradle/wrapper
cp projects/backup/gradle-wrapper.jar \
   projects/<项目名>/gradle/wrapper/gradle-wrapper.jar
cp projects/backup/gradlew projects/<项目名>/gradlew
cp projects/backup/gradlew.bat projects/<项目名>/gradlew.bat
chmod +x projects/<项目名>/gradlew
```

另写（可改 distribution 版本，但须与备份 jar 兼容）：

- `projects/<项目名>/gradle/wrapper/gradle-wrapper.properties`

`projects/backup/` **不是**业务工程：不要 `include` 进 settings，不要当 `applicationId` 项目目录。

## `.gitignore` 必含

```text
local.properties
*.jks
*.keystore
keystore.properties
google-services.json
```

`google-services.json` 若团队约定入库，须在 MR 说明里写清不含生产密钥变体，且 debug/release 分开。
