# 模块与入口怎么摆

下面路径都相对某个业务工程根目录，也就是 `projects/<项目名>/`。

## 单模块

```text
app/src/main/java/<package>/
  App.kt                 # @HiltAndroidApp
  MainActivity.kt        # ComponentActivity + setContent
  ui/theme/Theme.kt
  ui/theme/Color.kt
  ui/theme/Type.kt
  navigation/AppNavHost.kt
```

## 多模块（商业默认）

```text
app/          → 依赖所有 feature，只放 Application、NavHost、主题委托
core/model/   → 无 Android 依赖（能做成 java/kotlin 纯库更好）
core/common/  → AppResult、CoroutineDispatchers
core/network/ → OkHttp/Retrofit 单例、拦截器接口
core/database/→ RoomDatabase、DAO
core/ui/      → 可选：公共 Compose 组件与主题
feature/foo/  → 该功能的 ui/viewmodel/domain/data/navigation
```

`core:model` 被所有人依赖，禁止反向依赖 Android 库。

## Application

```kotlin
@HiltAndroidApp
class App : Application()
```

`AndroidManifest.xml` 的 `<application>` 指定该类，`MainActivity` 加 `@AndroidEntryPoint`。

## 导航宿主

只在 `:app` 组装图。feature 对外暴露 `fun NavGraphBuilder.fooGraph(onBack: () -> Unit)`，不持有全局 `NavController` 业务。

路由字符串集中在 feature 的 `FooRoute` 对象，禁止散落魔法字符串。
