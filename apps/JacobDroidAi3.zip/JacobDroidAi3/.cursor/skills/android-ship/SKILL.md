---
name: android-ship
description: >-
  移动发版：versionCode、渠道包、签名、商店提审材料与拒包风险。
  在用户说发版、打包、提审、升版本、写应用商店更新说明时使用。
---

# 移动发版

## 0. 身份

核对版本与清单，指出必须人工点的商店后台步骤。不要假装已经提交审核。

## 必须 STOP

- 擅自提高 `minSdk`、改 `applicationId`
- 把 keystore 密码写进仓库
- 未确认就切正式/测试 API 或支付环境

## 不要问，直接做（已知可跳过提问）

- 对比上一版 versionCode / versionName
- 按项目已有 task 写打包命令，不发明 task

## 步骤

### Step 1: 发版意图

未知则问：内测 / 正式；Play 还是国内渠道；哪个 flavor。

### Step 2: 版本

- `versionCode` **必须比上一版大**。
- `versionName` 跟团队约定。
- 商店「更新说明」只写用户能感知的变化。

### Step 3: 清单

```
- [ ] versionCode / versionName 已对比正确
- [ ] 更新说明与本次 diff 一致
- [ ] release 签名在，密码不在仓库
- [ ] minify / 映射文件（mapping）按项目惯例（崩溃还原要用）
- [ ] 各 flavor / 渠道：包名、应用名、图标、资源不串
- [ ] 新增权限、广告、支付已在隐私政策/商店表单能对上
- [ ] 调试入口、测试服开关、日志级别已按正式环境收敛
- [ ] 关键配置指向本次要发的环境
```

### Step 4: 打包命令

```bash
./gradlew :app:assembleRelease
# 或
./gradlew :app:bundleRelease
```

多渠道用项目文档里的任务名。

### Step 5: 仍需人工（写清楚）

- 钥匙密码、商店后台上传、各国内市场重复提交
- 隐私政策链接、截图、年龄分级、权限用途表
- 映射文件上传到崩溃平台（若项目有）

## 输出

```markdown
## 发版摘要
- 版本：versionName (versionCode)
- 产物：APK / AAB + task
- 渠道/flavor：
## 已核对
## 仍需你在商店/渠道后台做的
## 拒包与回滚风险
```

STATUS：`DONE` / `DONE_WITH_CONCERNS` / `BLOCKED` / `NEEDS_CONTEXT`。
