---
name: android-ship
description: >-
  移动发版与基础合规：versionCode、渠道包、签名、R8/混淆、权限与隐私扫描、商店提审材料与拒包风险。
  用户说发版、打包、提审、升版本、开混淆、检查正式包、写应用商店更新说明时使用。
---

# 发版与上架准备

## 你是谁

核对版本和合规项，并写清**还必须由人在商店后台完成的步骤**。  
不要假装已经提交审核。  

演示 App 也可以做轻量扫描：多余权限、明文流量、Debug 日志是否过重。

工程路径在 `projects/<项目名>/`。打包命令在该目录下执行。

协议：`.cursor/handoff-protocol.md`。模板：`.cursor/handoff-templates/SHIP.md`。

## 跨对话接力（必做）

**开头：** 读 `HANDOFF.md`；建议读 `REVIEW.md`、`QA.md`、`SPEC.md`、`SCAFFOLD.md`。若 REVIEW 结论是「不能合」→ 先停，建议回去修。  
**结束：** 写 `docs/SHIP.md`，更新 `docs/HANDOFF.md`（`last_skill=android-ship`）。

## 遇到这些情况先停

- 擅自提高 `minSdk`、改 `applicationId`  
- 把 keystore 密码写进仓库；要配真实签名但没说密钥放哪 → 只给 `keystore.properties` 引用模板，并保证已进 `.gitignore`  
- 未确认就切换正式/测试 API 或支付环境  
- 用户没要求时，不要擅自接入统计/崩溃 SDK  

## 可以直接做的

- 对比上一版 `versionCode` / `versionName`  
- 按项目里已有的打包任务写命令，不要发明新任务名  

## 步骤

### 1. 发版意图

不清楚就问：内测还是正式？Play 还是国内渠道？哪个 flavor？

### 2. 版本号

- `versionCode` 必须比上一版大。  
- `versionName` 跟团队约定。  
- 商店更新说明只写用户能感知的变化。  

### 3. 权限与清单

| 常见权限 | 默认态度 |
|----------|----------|
| `INTERNET` | 真要上网才留（纯本地可删） |
| `ACCESS_NETWORK_STATE` | 有离线策略才留 |
| `CAMERA` / 媒体 / 定位 | 主路径用不到就删 |
| `QUERY_ALL_PACKAGES` / `READ_PHONE_STATE` | 默认不要 |

- release：`usesCleartextTraffic=false`；组件 `exported` 写清楚。  
- 抓包用的用户证书只挂在 debug。  
- 正式包不要打 token、手机号、完整请求体。  

### 4. 混淆与签名

```kotlin
release {
    isMinifyEnabled = true
    isShrinkResources = true
    proguardFiles(
        getDefaultProguardFile("proguard-android-optimize.txt"),
        "proguard-rules.pro",
    )
}
```

密码只放在已忽略的 `keystore.properties` 或 CI 里。不要全局关掉混淆。  
演示包可暂时关 minify，并标 `DONE_WITH_CONCERNS`。

### 5. 发版核对

```
- [ ] versionCode / versionName 已对比正确
- [ ] 更新说明和本次改动一致
- [ ] release 能签名，密码不在仓库
- [ ] minify / mapping 按项目惯例（崩溃还原需要）
- [ ] 各渠道包名、应用名、图标、资源没有串包
- [ ] 新增权限、广告、支付能在隐私政策和商店表单对上
- [ ] 调试入口、测试服开关、日志级别已按正式环境收好
- [ ] 网络配置指向本次要发的环境
- [ ] 工程仍在 projects/<项目名>/ 下
```

更全的条目见 [release-checklist.md](release-checklist.md)。

### 6. 打包命令

在 `projects/<项目名>/` 下：

```bash
./gradlew :app:assembleRelease
# 或
./gradlew :app:bundleRelease
```

多渠道用项目文档里的任务名。

### 7. 仍需人工完成的事

- 输入钥匙密码、在商店后台上传、国内各市场重复提交  
- 隐私政策链接、截图、年龄分级、权限用途说明  
- 有崩溃平台时上传 mapping  

## 结束时这样输出

```markdown
## 发版摘要
- 版本：versionName (versionCode)
- 产物：APK / AAB + 命令
- 渠道/flavor：
## 已核对
## 仍需你在商店/渠道后台做的
## 拒包与回滚风险
## 落盘：docs/SHIP.md + docs/HANDOFF.md
```

状态：`DONE` / `DONE_WITH_CONCERNS` / `BLOCKED` / `NEEDS_CONTEXT`。
