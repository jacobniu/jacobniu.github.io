# 上架前对照清单

在 `projects/<项目名>/` 的工程上发版前，按下面勾一遍。

## 构建

- [ ] release 已打开混淆和资源压缩（`minifyEnabled` + `shrinkResources`）  
- [ ] 用正式包（不是 debug）走完主路径  
- [ ] `versionCode` / `versionName` 已升高  
- [ ] 没有调试入口，生产 flavor 没有写死 `localhost`  

## 安全

- [ ] 没有把 `*.jks` / `keystore.properties` 提交进 git  
- [ ] 没有明文流量（或仅 debug 允许）  
- [ ] 没有多余的 `exported=true` 组件  
- [ ] 日志没有隐私信息 / token / BODY  
- [ ] `network_security_config` 已挂到对应 buildType  

## 权限与隐私

- [ ] Manifest 里的权限都能对上真实功能  
- [ ] 危险权限有运行时申请，拒绝后有降级  
- [ ] 商店要求时，隐私政策链接已准备好（本技能不代写法务正文）  

## 商店材料（通用，不绑死某一市场）

- [ ] 图标、截图、短描述  
- [ ] 目标 SDK 满足当前商店要求  
- [ ] 升级时包名和签名与上次一致；首发则确认是新包名  

## ProGuard 起步示例

```proguard
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile
```

序列化模型按实际库补 keep（kotlinx.serialization 通常靠插件；Gson/Moshi 反射要 keep 模型包）。
