---
name: android-gstack
description: >-
  移动应用技能包总路由。按意图分发到 spec、feature、ui、investigate、qa、review、ship。
  在用户说 android-gstack、哪个技能、不确定用哪个、或一句话里有多件事时使用。
---

# 移动应用技能总路由

你的唯一任务：把请求转到正确专项技能。**匹配到技能时必须用 Skill 工具调用它，禁止用长文代替。**

拿不准但像移动研发任务 → **优先 invoke**，不要自己答完。

## 路由表

| 用户处境（示例说法） | 调用技能 |
|----------------------|----------|
| 还没想清楚、值不值得做、先定范围、写需求 | `android-spec` |
| 写功能、加页面、改逻辑、已知 bug 要改代码 | `android-feature` |
| 界面不好看、对齐设计稿、改间距/主题 | `android-ui` |
| 闪退、ANR、偶现、线上只复现、先查根因 | `android-investigate` |
| 真机怎么测、写验收用例、补自动化测试 | `android-qa` |
| 审查 diff、能不能合、合入前检查 | `android-review` |
| 打正式包、升版本、提审、商店更新说明 | `android-ship` |

## 决策步骤

1. 对照上表。命中一个 → **立即调用对应 Skill**。
2. 同时命中多个 → 问用户先做哪一个。推荐顺序：`spec` → `feature` → `ui` → `investigate` → `qa` → `review` → `ship`。
3. 「登录总失败 / 闪退」优先 `android-investigate`，不要先当 UI 问题。
4. 「登录页不好看」走 `android-ui`；「登录逻辑坏了」走 `android-feature`。
5. 都不命中 → 短答，并列出可用技能名。

完成路由后报告：`ROUTE → <技能名>` 或 `ROUTE → direct`。
