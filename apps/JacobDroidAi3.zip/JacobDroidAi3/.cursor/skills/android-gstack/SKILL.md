---
name: android-gstack
description: >-
  移动应用技能包总路由（分诊入口）。按意图分发到产品、设计、开发、质量、发布各组技能。
  用户说 android-gstack、哪个技能、不确定用哪个、或一句话里有多件事时使用。
---

# 技能总路由（分诊）

你的任务只有一件：把用户请求转到正确的专项技能。  
**匹配到技能后，必须调用该 Skill，不要用长文自己做完。**

拿不准、但明显是移动研发任务 → 优先调用对应技能，不要自己答完。  
**分诊机制保持不变**：先在本技能判断，再进入一个专项技能。

## 跨对话继续（接力）

若用户说「继续某某项目」或给出 `projects/<名>/`：

1. **先读** `projects/<名>/docs/HANDOFF.md`（没有则按下方路由表正常分诊）。  
2. 有 `suggested_next` 且用户没点名别的技能 → **优先调用** `suggested_next`。  
3. 路由完成后仍报告：`ROUTE → <技能名>`；可附带一句「已读 HANDOFF，上次是 …」。  

产物协议：`.cursor/handoff-protocol.md`（借鉴 gstack 落盘接力，不是多 slash）。

## 分组对照表

### 产品

| 用户大概在说什么 | 调用 |
|------------------|------|
| 还没想清楚、值不值得做、先定范围、写需求 | `android-spec` |

### 设计

| 用户大概在说什么 | 调用 |
|------------------|------|
| 按参考图出设计、HTML 多屏预览、先看界面再开发 | `android-design` |

### 开发

| 用户大概在说什么 | 调用 |
|------------------|------|
| 新建工程、创建模板、加模块、配 Gradle/Hilt | `android-project-scaffold` |
| 接接口、写仓库、Room、本地缓存、只有本地没有后端 | `android-data-layer` |
| 写功能、加页面、改逻辑、已知 bug 要改代码 | `android-feature` |
| 已有 Compose 不好看、对齐设计稿/HTML、改间距主题（不改逻辑） | `android-ui` |
| 闪退、ANR、偶现、线上难复现、先查原因 | `android-investigate` |

### 质量

| 用户大概在说什么 | 调用 |
|------------------|------|
| 真机怎么测、写验收用例、补自动化测试 | `android-qa` |
| 审查改动、能不能合、合入前检查 | `android-review` |

### 发布

| 用户大概在说什么 | 调用 |
|------------------|------|
| 打正式包、升版本、提审、开混淆、检查正式包 | `android-ship` |

## 怎么判断

1. 对照上表，命中一个 → **马上调用对应 Skill**。  
2. 同时像多个 → 问用户先做哪一个。推荐顺序：  
   `spec` → `design` → `scaffold` → `data-layer` → `feature` → `ui` → `investigate` → `qa` → `review` → `ship`  
   （已有工程可从 `spec` / `feature` 开始；纯建工程从 `scaffold` 开始。）  
3. 出设计 / HTML → `android-design`；改已有 Compose 观感 → `android-ui`（不要混）。  
4. 从零搭工程 → `android-project-scaffold`（必须写到 `projects/<项目名>/`，不能只口述）。  
5. 只接 API/Room → `android-data-layer`；页面和数据都要做 → 可先 data-layer 再 feature。  
6. 登录失败伴随闪退 → 优先 `android-investigate`。  
7. 登录逻辑坏了 → `android-feature`；登录页丑且代码已有 → `android-ui`。  
8. 都不像 → 简短回答，并按分组列出可用技能名。

完成后报告：`ROUTE → <技能名>`，或 `ROUTE → direct`。
