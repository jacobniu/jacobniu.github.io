#!/usr/bin/env python3
# =============================================================================
# 文件职责：强制「业务项目产物」与「技能包」隔离。
#
# 什么时候会跑到：
#   - 准备写入/编辑文件之前（preToolUse，匹配 Write / Edit 等）
#
# 硬性规则：
#   用本方案开发出来的 App 工程、设计预览 HTML、业务源码等，
#   一律放在仓库根下的 projects/ 目录中，例如：
#       projects/TodoApp/...
#       projects/TodoApp/design-preview/xxx.html
#   不得写在技能包根目录，以免和 .cursor、AGENTS.md 等搅在一起。
#
# 仍然允许直接改技能包自身（白名单），例如：
#   .cursor/、AGENTS.md、.gitignore、本 hooks 目录等。
# =============================================================================

from __future__ import annotations

import json
import sys
from pathlib import Path

# 业务产物必须落在该目录下（相对仓库根）
PROJECTS_DIR_NAME = "projects"

# 允许在技能包根目录改动的路径前缀 / 文件名（维护技能包本身）
SKILLPACK_ALLOW_PREFIXES = (
    ".cursor/",
    ".git/",
)

SKILLPACK_ALLOW_FILES = {
    "agents.md",
    ".gitignore",
    "readme.md",
    "license",
    "license.md",
}


def _out(payload: dict) -> None:
    """把允许/拒绝结果写回给 Cursor。"""
    sys.stdout.write(json.dumps(payload, ensure_ascii=False))
    sys.stdout.write("\n")


def _text(data: dict, *keys: str) -> str:
    """从钩子入参或嵌套 arguments 里取路径等字符串字段。"""
    for key in keys:
        value = data.get(key)
        if isinstance(value, str) and value:
            return value
    args = data.get("arguments")
    if isinstance(args, dict):
        for key in keys:
            value = args.get(key)
            if isinstance(value, str) and value:
                return value
        for nest_key in ("input", "params"):
            nested = args.get(nest_key)
            if isinstance(nested, dict):
                for key in keys:
                    value = nested.get(key)
                    if isinstance(value, str) and value:
                        return value
    return ""


def _extract_path(data: dict) -> str:
    return _text(
        data,
        "file_path",
        "path",
        "target_file",
        "targetFile",
    )


def _repo_root() -> Path:
    return Path.cwd().resolve()


def _rel_posix(root: Path, target: Path) -> str:
    """得到相对仓库根的 posix 路径；不在根下则返回绝对 posix。"""
    try:
        return target.resolve().relative_to(root).as_posix()
    except ValueError:
        return target.resolve().as_posix().replace("\\", "/")


def _is_skillpack_allowed(rel: str) -> bool:
    """是否属于技能包自身文件（允许写在根下）。"""
    lower = rel.lower()
    if lower in SKILLPACK_ALLOW_FILES:
        return True
    for prefix in SKILLPACK_ALLOW_PREFIXES:
        if lower.startswith(prefix) or lower == prefix.rstrip("/"):
            return True
    return False


def _is_under_projects(rel: str) -> bool:
    """是否已经落在 projects/ 之下。"""
    lower = rel.lower()
    return lower == PROJECTS_DIR_NAME or lower.startswith(PROJECTS_DIR_NAME + "/")


def _looks_like_project_artifact(rel: str) -> bool:
    """
    看起来像「业务项目产物」的路径（若出现在根下则应拒绝）。
    技能包白名单已在前面放行，这里主要拦 App 工程与设计预览。
    """
    lower = rel.lower()
    name = lower.rsplit("/", 1)[-1]

    # 设计预览、常见 Gradle/Android 工程入口
    if lower.startswith("design-preview/") or "/design-preview/" in lower:
        return True
    if name in {
        "settings.gradle.kts",
        "settings.gradle",
        "gradle.properties",
        "gradlew",
        "gradlew.bat",
        "androidmanifest.xml",
        "proguard-rules.pro",
        "network_security_config.xml",
        "libs.versions.toml",
        "local.properties",
        "google-services.json",
    }:
        return True
    if lower.startswith("app/") or "/app/src/" in lower:
        return True
    if lower.startswith("gradle/") or lower.startswith("core/") or lower.startswith("feature/"):
        return True
    if name in {"build.gradle.kts", "build.gradle"} and not lower.startswith(".cursor/"):
        return True
    if lower.endswith(".kt") or lower.endswith(".kts"):
        # 根目录或非 projects 下的 Kotlin/Gradle 业务文件
        return True
    if lower.endswith(".xml") and ("res/" in lower or "manifest" in lower):
        return True
    return False


def main() -> int:
    try:
        data = json.load(sys.stdin)
    except json.JSONDecodeError:
        _out({"permission": "allow"})
        return 0
    if not isinstance(data, dict):
        _out({"permission": "allow"})
        return 0

    path_str = _extract_path(data)
    if not path_str:
        _out({"permission": "allow"})
        return 0

    root = _repo_root()
    target = Path(path_str)
    if not target.is_absolute():
        target = (root / path_str).resolve()
    else:
        target = target.resolve()

    rel = _rel_posix(root, target)

    # 已在 projects/ 下：符合隔离规则
    if _is_under_projects(rel):
        _out({"permission": "allow"})
        return 0

    # 技能包自身：允许
    if _is_skillpack_allowed(rel):
        _out({"permission": "allow"})
        return 0

    # 其余路径若像业务产物，或干脆写在根下不明位置：拒绝并引导到 projects/
    if _looks_like_project_artifact(rel) or "/" not in rel:
        _out(
            {
                "permission": "deny",
                "user_message": (
                    "业务项目产物必须放在 projects/ 目录下，已拦截写到技能包根目录的操作。"
                ),
                "agent_message": (
                    "硬性规则：用本方案开发的 App 工程、源码、设计预览 HTML 等，"
                    "一律写入 `projects/<项目名>/` 下，与技能包（.cursor、AGENTS.md）隔离。"
                    f"当前路径 `{rel}` 不在 projects/ 内。"
                    "请改为例如 `projects/TodoApp/...` 或 `projects/TodoApp/design-preview/...`。"
                ),
            }
        )
        return 0

    # 根下其它未知路径也拒绝，避免把产物散落到技能包旁
    _out(
        {
            "permission": "deny",
            "user_message": "请把项目相关文件写到 projects/<项目名>/ 下。",
            "agent_message": (
                f"路径 `{rel}` 不在技能包白名单，也不在 `projects/` 下。"
                "业务产物请放到 `projects/<项目名>/`；维护技能包请只改 `.cursor/`、AGENTS.md 等。"
            ),
        }
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
