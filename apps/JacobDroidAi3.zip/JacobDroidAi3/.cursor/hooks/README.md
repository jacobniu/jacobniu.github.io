# 门禁脚本说明

本目录放的是技能包的自动检查脚本。  
总开关在 `.cursor/hooks.json`（JSON 不能写注释，所以说明写在这里）。

| 脚本 | 什么时候跑 | 干什么 |
|------|------------|--------|
| `protect_android_secrets.py` | 读文件前、执行命令前 | 拦住密钥库读取，以及往公网粘贴/外带密钥 |
| `check_android_projects_root.py` | 写入前 | **硬性规则**：业务文件必须写在 `projects/` 下 |
| `check_android_freeze.py` | 写入前 | 若开了目录冻结，禁止改范围外的文件 |
| `after_android_sensitive_edit.py` | 改完文件后 | 改了 Manifest、混淆规则等时，追加自检提醒 |

## 业务和技能包怎么分开

```text
本仓库根/                      ← 技能包（.cursor、AGENTS.md）
  projects/
    backup/                    ← 共享资产（如 gradle-wrapper.jar），不是业务 App
    TodoApp/                   ← 用本方案生成的 App
      design-preview/          ← 该 App 的 HTML 预览
```

不要把 `app/`、`settings.gradle.kts`、根目录下的 `design-preview/` 直接写在技能包根上。  
`gradle-wrapper.jar` 从 `projects/backup/` 复制到各工程，`gradlew` / `gradlew.bat` 同样从 backup 复制，见 `android-project-scaffold`。  
每个脚本文件顶部都有中文说明，打开即可看到它负责什么。

Hook 命令须用 **`python3`**（见 `hooks.json`）；系统 `python` 若是 2.x 会导致 fail-closed 拦死终端。
