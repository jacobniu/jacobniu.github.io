#!/usr/bin/env python3
# =============================================================================
# 文件职责：改完敏感配置后，给 Agent 补一句自检提醒（不拦截写入）。
#
# 什么时候会跑到：
#   - 文件已经被编辑之后（afterFileEdit）
#
# 主要做什么：
#   针对 AndroidManifest、网络安全配置、ProGuard、app 模块 Gradle 等敏感文件，
#   在上下文里追加简短中文提醒，提醒检查权限、明文流量、混淆与签名是否合规。
#   本钩子只「提醒」，不阻止保存。
# =============================================================================

from __future__ import annotations

import json
import sys


def _text(data: dict, *keys: str) -> str:
    """从钩子入参或嵌套 arguments 里取路径字符串。"""
    for key in keys:
        value = data.get(key)
        if isinstance(value, str) and value:
            return value
    args = data.get("arguments")
    if isinstance(args, dict):
        for key in keys:
            value = args.get(key)
            if isinstance(value, str) and value:
                return value
    return ""


def reminder_for(path: str) -> str:
    """按文件名返回对应的中文自检提醒；无关文件返回空串。"""
    lower = path.replace("\\", "/").lower()
    name = lower.rsplit("/", 1)[-1]
    if name == "androidmanifest.xml":
        return (
            "刚改了 AndroidManifest。自检：每个新增 permission 是否有调用点；"
            "exported 是否显式；release 是否仍允许 cleartext；"
            "调试 Activity 是否只在 src/debug。细则见 android-ship 与 android-commercial 规则。"
        )
    if name == "network_security_config.xml":
        return (
            "刚改了 network_security_config。确认用户证书仅挂在 debug，"
            "release 禁止 cleartext。正式抓包配置不得打进商店包。"
        )
    if name == "proguard-rules.pro":
        return (
            "刚改了 ProGuard。不要用全局 -dontobfuscate；"
            "只为反射/序列化模型补 keep，并用 release 包冒烟。发版见 android-ship。"
        )
    if name in {"build.gradle.kts", "build.gradle"} and "app" in lower:
        return (
            "刚改了 app 的 Gradle。上架任务须确认 release minify/shrink 已打开，"
            "且 signingConfig 不把密码写进仓库。发版核对用 android-ship。"
            "另确认该工程位于 projects/<项目名>/ 下，勿写在技能包根目录。"
        )
    return ""


def main() -> int:
    try:
        data = json.load(sys.stdin)
    except json.JSONDecodeError:
        print("{}")
        return 0
    if not isinstance(data, dict):
        print("{}")
        return 0

    path = _text(data, "file_path", "path", "target_file")
    note = reminder_for(path)
    if note:
        sys.stdout.write(json.dumps({"additional_context": note}, ensure_ascii=False))
    else:
        sys.stdout.write("{}")
    sys.stdout.write("\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
