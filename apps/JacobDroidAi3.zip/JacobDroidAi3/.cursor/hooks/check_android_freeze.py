#!/usr/bin/env python3
# =============================================================================
# 文件职责：目录冻结门禁——调查问题时把改动锁在指定目录里。
#
# 什么时候会跑到：
#   - 准备写入/编辑文件之前（preToolUse，匹配 Write / Edit 等）
#
# 主要做什么：
#   1. 若存在 .cursor/state/freeze-dir.txt，则只允许改该目录下的文件；
#   2. 试图改冻结范围以外的路径时直接拒绝，避免「查一个模块却改飞全仓」；
#   3. 维护冻结文件本身始终允许，方便解除或调整范围。
#
# 说明：本文件不管「项目必须放在 projects/」——那条规则由
#       check_android_projects_root.py 负责。
# =============================================================================

from __future__ import annotations

import json
import sys
from pathlib import Path

# 冻结范围配置文件（相对仓库根目录）
STATE_REL = Path(".cursor") / "state" / "freeze-dir.txt"


def _out(payload: dict) -> None:
    """把允许/拒绝结果写回给 Cursor。"""
    sys.stdout.write(json.dumps(payload, ensure_ascii=False))
    sys.stdout.write("\n")


def _text(data: dict, *keys: str) -> str:
    """从钩子入参或嵌套 arguments 里取路径等字符串字段。"""
    for key in keys:
        value = data.get(key)
        if isinstance(value, str) and value:
            return value
    args = data.get("arguments")
    if isinstance(args, dict):
        for key in keys:
            value = args.get(key)
            if isinstance(value, str) and value:
                return value
        for nest_key in ("input", "params"):
            nested = args.get(nest_key)
            if isinstance(nested, dict):
                for key in keys:
                    value = nested.get(key)
                    if isinstance(value, str) and value:
                        return value
    return ""


def _repo_root() -> Path:
    """钩子运行时的当前工作目录就是仓库根。"""
    return Path.cwd().resolve()


def _read_freeze_dir(root: Path) -> Path | None:
    """读取冻结目录；没有配置或内容为空则返回 None（表示不冻结）。"""
    state = root / STATE_REL
    if not state.is_file():
        return None
    raw = state.read_text(encoding="utf-8", errors="replace").strip()
    if not raw:
        return None
    line = raw.splitlines()[0].strip().replace("\\", "/")
    if not line:
        return None
    p = Path(line)
    if not p.is_absolute():
        p = (root / line).resolve()
    else:
        p = p.resolve()
    return p


def _is_under(child: Path, parent: Path) -> bool:
    """判断 child 是否落在 parent 目录之下。"""
    try:
        child.relative_to(parent)
        return True
    except ValueError:
        return False


def _extract_path(data: dict) -> str:
    """从本次工具调用里取出目标文件路径。"""
    return _text(
        data,
        "file_path",
        "path",
        "target_file",
        "targetFile",
    )


def main() -> int:
    try:
        data = json.load(sys.stdin)
    except json.JSONDecodeError:
        _out({"permission": "allow"})
        return 0
    if not isinstance(data, dict):
        _out({"permission": "allow"})
        return 0

    root = _repo_root()
    freeze = _read_freeze_dir(root)
    if freeze is None:
        # 未开启冻结：放行（项目目录隔离由另一个钩子负责）
        _out({"permission": "allow"})
        return 0

    path_str = _extract_path(data)
    if not path_str:
        _out({"permission": "allow"})
        return 0

    # 允许改冻结配置本身，否则无法解除冻结
    norm = path_str.replace("\\", "/")
    if norm.endswith(".cursor/state/freeze-dir.txt") or "/.cursor/state/freeze-dir.txt" in norm:
        _out({"permission": "allow"})
        return 0

    target = Path(path_str)
    if not target.is_absolute():
        target = (root / path_str).resolve()
    else:
        target = target.resolve()

    if _is_under(target, freeze):
        _out({"permission": "allow"})
        return 0

    _out(
        {
            "permission": "deny",
            "user_message": f"已冻结编辑范围：{freeze}。越界写入已拦截。",
            "agent_message": (
                f"目录冻结生效，只允许修改 `{freeze}` 下文件。"
                "若需改其他路径：请用户同意后删除 `.cursor/state/freeze-dir.txt`，"
                "或更新冻结路径。见 android-investigate。"
            ),
        }
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
