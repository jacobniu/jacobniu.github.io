#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# =============================================================================
# 文件职责：保护签名密钥，并拦截可能把内容泄到公网的命令。
#
# 什么时候会跑到：
#   - 准备读取文件之前（beforeReadFile）
#   - 准备执行终端命令之前（beforeShellExecution）
#
# 主要做什么：
#   1. 禁止直接读取 .jks / .keystore / .p12 等证书文件；
#   2. 读取可能含密码的 keystore.properties 时，改为询问用户是否允许；
#   3. 禁止把文件传到 pastebin、ngrok 等公网粘贴/穿透地址；
#   4. 禁止用 git/scp/curl 等命令把签名材料带出仓库。
# =============================================================================

from __future__ import annotations

import json
import sys

# 直接拒绝读取的证书/密钥库后缀
DENY_READ_SUFFIXES = (
    ".jks",
    ".keystore",
    ".p12",
)

# 可能含密码：不直接拒绝，改为让用户确认
ASK_READ_NAMES = (
    "keystore.properties",
    "key.properties",
)

# 公网粘贴站、临时传文件、内网穿透等危险目标
EXFIL_MARKERS = (
    "pastebin.com",
    "gist.github.com",
    "hastebin.com",
    "transfer.sh",
    "file.io",
    "ngrok.io",
    "ngrok.com",
    "loca.lt",
    "serveo.net",
)

# 命令行里一旦出现这些文件名，再叠加外带动作就拦截
SHELL_SECRET_MARKERS = (
    ".jks",
    ".keystore",
    "keystore.properties",
    "key.properties",
)


def _out(payload: dict) -> None:
    """把允许/拒绝结果写回给 Cursor。"""
    sys.stdout.write(json.dumps(payload, ensure_ascii=False))
    sys.stdout.write("\n")


def _text(data: dict, *keys: str) -> str:
    """从钩子入参里按候选字段名取第一个非空字符串。"""
    for key in keys:
        value = data.get(key)
        if isinstance(value, str) and value:
            return value
    return ""


def _nested_path(data: dict) -> str:
    """从 arguments 嵌套结构里尽量抠出文件路径。"""
    args = data.get("arguments")
    if isinstance(args, dict):
        return _text(args, "path", "file_path", "target_file")
    return ""


def handle_read(path: str) -> dict:
    """判断这次「读文件」是否允许。"""
    lower = path.replace("\\", "/").lower()
    name = lower.rsplit("/", 1)[-1]
    if lower.endswith(DENY_READ_SUFFIXES):
        return {
            "permission": "deny",
            "user_message": "已拦截对签名证书/密钥库文件的读取。",
            "agent_message": (
                "不要读取 .jks/.keystore/.p12。签名配置只引用 keystore.properties 的路径，"
                "密钥库本身不入库、不进上下文。"
            ),
        }
    if name in ASK_READ_NAMES:
        return {
            "permission": "ask",
            "user_message": "该文件通常含签名密码，确认是否让 Agent 读取。",
            "agent_message": "keystore.properties 含密码。优先只改 .gitignore 与 gradle 引用，避免把口令读进对话。",
        }
    return {"permission": "allow"}


def handle_shell(command: str) -> dict:
    """判断这次「执行命令」是否允许。"""
    lower = command.lower()
    if any(marker in lower for marker in EXFIL_MARKERS):
        return {
            "permission": "deny",
            "user_message": "已拦截可能把内容传到公网粘贴/穿透服务的命令。",
            "agent_message": (
                "禁止把文件或日志上传到 pastebin/gist/transfer.sh/ngrok 等公网地址。"
                "内网环境不得做内网穿透或生成公网访问链接。"
            ),
        }
    if any(marker in lower for marker in SHELL_SECRET_MARKERS) and any(
        token in lower for token in ("git add", "git commit", "scp ", "curl ", "wget ", "invoke-webrequest")
    ):
        return {
            "permission": "deny",
            "user_message": "已拦截把签名材料带出仓库或上传的命令。",
            "agent_message": "不要 git add/commit 或上传 .jks、.keystore、keystore.properties。",
        }
    return {"permission": "allow"}


def main() -> int:
    try:
        data = json.load(sys.stdin)
    except json.JSONDecodeError:
        _out({"permission": "allow"})
        return 0
    if not isinstance(data, dict):
        _out({"permission": "allow"})
        return 0

    command = _text(data, "command")
    path = _text(data, "file_path", "path") or _nested_path(data)
    event = _text(data, "hook_event_name", "event").lower()

    # 终端命令优先按 shell 规则处理
    if command and (event.startswith("beforeshellexecution") or not path):
        _out(handle_shell(command))
        return 0
    if path:
        _out(handle_read(path))
        return 0
    if command:
        _out(handle_shell(command))
        return 0
    _out({"permission": "allow"})
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
