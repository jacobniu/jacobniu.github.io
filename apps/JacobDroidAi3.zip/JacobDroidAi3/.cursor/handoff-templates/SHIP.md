# 发版 SHIP

- project: `<项目名>`
- updated: ``
- versionName: ``
- versionCode: ``

## 产物

- APK / AAB：
- 命令：

## 已核对

- 

## 仍需人工（商店后台）

- 

## 拒包 / 回滚风险

- 

## 对照产物

- REVIEW / QA / SPEC 是否已读：
