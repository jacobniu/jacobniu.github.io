# 工程骨架 SCAFFOLD

- project: `<项目名>`
- root: `projects/<项目名>/`
- updated: ``
- preset: demo-single | commercial-multi

## 标识

- applicationId：
- 包名根：
- minSdk / targetSdk：

## 模块

- 

## 入口

- Application：
- Activity：
- 导航宿主：

## 如何运行

```bash
cd projects/<项目名>
./gradlew :app:assembleDebug
```

Android Studio 打开：`projects/<项目名>/`

## 组装结果

- 已跑通 / 未跑（原因）：

## 建议下一步技能

- 
