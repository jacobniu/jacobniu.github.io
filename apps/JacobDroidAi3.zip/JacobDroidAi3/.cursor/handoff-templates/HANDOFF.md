# Handoff 索引

- project: `<项目名>`
- root: `projects/<项目名>/`
- last_skill: ``
- last_status: ``
- suggested_next: ``
- updated: ``

## 产物一览

| 产物 | 路径 | 状态 | 备注 |
|------|------|------|------|
| SPEC | docs/SPEC.md | missing | |
| DESIGN | docs/DESIGN.md | missing | |
| SCAFFOLD | docs/SCAFFOLD.md | missing | |
| DATA | docs/DATA.md | missing | |
| FEATURE | docs/FEATURE.md | missing | |
| QA | docs/QA.md | missing | |
| REVIEW | docs/REVIEW.md | missing | |
| SHIP | docs/SHIP.md | missing | |
| INVESTIGATE | docs/INVESTIGATE.md | missing | |

状态填：`present` / `missing` / `stale`（过时待更新）。

## 未收口 / 风险

- （无则写「无」）

## 下一对话怎么接

用 Agent 模式打开本仓库，可说：

`android-gstack：继续 projects/<项目名>，先读 docs/HANDOFF.md`
