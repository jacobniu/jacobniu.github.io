# 调查 INVESTIGATE

- project: `<项目名>`
- updated: ``
- status: DONE | NEEDS_CONTEXT | …

## 现象

- 

## 根因（或最大嫌疑）

- 

## 证据

- 

## 建议最小改动

- 

## 建议回归（真机）

1. 

## 冻结目录（若有）

- `.cursor/state/freeze-dir.txt` → 
