# 功能交付 FEATURE

- project: `<项目名>`
- updated: ``
- status: DONE | DONE_WITH_CONCERNS | …

## 本轮交付

- 

## 改动文件

- 

## 对照产物

- 已读 SPEC：是 / 否
- 已读 DESIGN：是 / 否
- 已读 DATA：是 / 否

## 真机验证步骤

1. 

## 未收口

- 

## 建议下一步技能

- 
