# 数据层 DATA

- project: `<项目名>`
- updated: ``
- mode: local_only | remote | local_plus_remote

## 仓库与模型

- Repository：
- 领域模型：
- 关键操作：

## 本地

- Room Entity / DAO / DB：
- DataStore：

## 远程（若有）

- Base URL 来源：
- API 列表：
- DTO / Mapper：

## 错误如何到 UI

- 

## 建议下一步技能

- 
