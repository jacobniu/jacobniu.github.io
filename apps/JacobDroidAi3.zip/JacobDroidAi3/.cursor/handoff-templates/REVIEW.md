# 审查 REVIEW

- project: `<项目名>`
- updated: ``
- verdict: 建议合 | 修完再合 | 不能合

## Critical

- 

## Warning

- 

## 对照产物

- FEATURE / QA / SPEC 是否已读：

## 建议下一步技能

- 
