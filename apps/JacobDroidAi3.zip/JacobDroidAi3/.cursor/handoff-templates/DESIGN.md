# 设计 DESIGN

- project: `<项目名>`
- updated: ``
- status: draft | ready_for_dev

## HTML 预览

- 主文件：`design-preview/<名>-preview.html`
- 打开方式：用浏览器打开上述文件（单文件、可跳转）

## 屏列表

| 屏 id | 名称 | 说明 | 可去往 |
|-------|------|------|--------|
| | | | |

## 主色 / 圆角 / 明暗

- 主色：
- 圆角：
- 暗色：是 / 否 / 双主题

## 状态示意（空 / 加载 / 错）

- 

## 实现提示（给 feature / ui）

- 

## 声明

视觉/交互原型，非商店定稿。落地：`android-feature` / `android-ui`。
