# AGENTS.md — 安卓技能包怎么用

本仓库是 **Cursor 技能包**（内容包括rule、skill、hook），用来辅助开发 Kotlin + Compose 商业 App。业务工程代码请放进 `projects/`目录。

**不会选技能时：先使用 `android-gstack`。** 由它导向到某一个专项技能。

---

## 硬性规则：业务放进 `projects/`

```text
本仓库根/                 ← 技能包（.cursor、AGENTS.md）
  projects/
    backup/               ← 共享资产（gradle-wrapper.jar / gradlew / gradlew.bat），不是业务 App
    TodoApp/              ← 你的 App 工程
      design-preview/     ← 该 App 的 HTML 界面预览
```

用本方案生成的工程、源码、设计预览，都放到 `projects/<项目名>/`。  
不要放到技能包根目录。门禁脚本 `check_android_projects_root.py` 会拦住违规写入。  
**Gradle Wrapper**：`gradle-wrapper.jar`、`gradlew`、`gradlew.bat` 均从 `projects/backup/` 复制到各工程（见 `android-project-scaffold`），不要公网下载 jar / 手写精简脚本，项目名不要用 `backup`。

跨对话接力产物也在工程内：`projects/<项目名>/docs/`（见下方「跨对话接力」）。

---

## 跨对话接力（产物落盘，借鉴 gstack）

技能之间**不强制**「上一个必须 DONE 才能开下一个」，但为解决跨对话丢上下文，采用 **落盘接力**：

```text
projects/<项目名>/docs/
  HANDOFF.md     ← 总索引（每步结束更新）
  SPEC.md DESIGN.md SCAFFOLD.md DATA.md …
  FEATURE.md QA.md REVIEW.md SHIP.md INVESTIGATE.md
projects/<项目名>/design-preview/   ← HTML 原型
```

- **开头**：有 HANDOFF 就先读，再读本技能需要的产物。  
- **结束**：写好本技能产物 + 更新 HANDOFF（含 `suggested_next` 与完成状态）。  
- 新对话可说：`android-gstack：继续 projects/TodoApp，先读 docs/HANDOFF.md`  

完整约定：`.cursor/handoff-protocol.md`；模板：`.cursor/handoff-templates/`。  
**不引入** gstack 式多 slash；总分诊仍是 `android-gstack`。

---

## 怎么开始

1. 用 **Agent 模式**打开本仓库。  
2. 第一句话建议这样说：  
   - `android-gstack：我想做一款待办 App，还没定要不要登录`  
   - 或直接点名：`按 android-project-scaffold 在 projects/TodoApp 创建模板`  
3. 等 Agent 报出 `ROUTE → …` 和完成状态（如 `DONE`）再进入下一步。  
4. 常见顺序：

```text
定需求(spec) → 看设计(design) → 建工程(scaffold) → 写数据(data-layer)
→ 写功能(feature) → 调界面(ui) → 验收(qa) → 审查(review) → 发版(ship)
```

工程已在 `projects/` 里、需求也清楚时，可直接从 `android-feature` 开始。  
只想先看界面效果，可先走 `android-design`。

## 完成状态（每个技能结束都要报）

| 状态 | 含义 |
|------|------|
| `DONE` | 交付物齐了，主路径可以进入下一步 |
| `DONE_WITH_CONCERNS` | 能继续，但必须列出未验证/未收口项（如真机未点、混淆未开、本机缺 SDK） |
| `BLOCKED` | 当前条件卡住；写明缺什么、已尝试什么 |
| `NEEDS_CONTEXT` | 缺关键信息或需你拍板；先别编造接口/堆栈/产品规则 |

怎么区分后两个：`NEEDS_CONTEXT` 多半是缺你一句话或一份材料，补上往往就能继续；`BLOCKED` 是条件不允许或已经试过仍过不去，需要换方案或等外部解除。

Agent 报完状态后，你再决定下一步说哪个技能（或继续 `android-gstack`）。  
若已写过 HANDOFF，也可直接：`继续 projects/<项目名>`，由 gstack 按 `suggested_next` 接力。

### 建议你跑一遍的最小闭环

每步说完等 Agent 做完，再进下一步：

1. `按 android-project-scaffold 新建：项目名 TodoApp，applicationId com.example.todo，预设 demo-single`  
2. （可选）`按 android-design：在 projects/TodoApp 下做列表和添加两屏 HTML 预览`  
3. `按 android-data-layer：只用本地 Room，任务字段 id/title/done/createdAt`  
4. `按 android-feature：做任务列表页，并挂到导航`  
5. `按 android-qa：写验收单；能补的自动化测试就补`

看设计：浏览器打开 `projects/TodoApp/design-preview/*.html`。  
跑 App：用 Android Studio 打开 **`projects/TodoApp/`**（不是仓库根目录）。  
接力索引：打开 `projects/TodoApp/docs/HANDOFF.md` 看上次做到哪、建议下一步是谁。

---

## 我该用哪个技能

### 产品

| 你现在的情况 | 用这个技能 |
|--------------|------------|
| 还没想清楚范围、登录/支付/权限，先别写代码 | `android-spec` |

### 设计

| 你现在的情况 | 用这个技能 |
|--------------|------------|
| 有参考图，或想先看多屏 HTML 原型（可简单跳转） | `android-design` |

### 开发

| 你现在的情况 | 用这个技能 |
|--------------|------------|
| 新建模板工程、加模块、配 Gradle / Hilt（直接写成文件） | `android-project-scaffold` |
| 接接口、Room、Repository、本地库 | `android-data-layer` |
| 写页面、改逻辑、原因已清楚的 bug | `android-feature` |
| 已有 Compose，只调好看（不改业务、不出设计稿） | `android-ui` |
| 闪退、卡死、偶现问题，先查原因 | `android-investigate` |

### 质量

| 你现在的情况 | 用这个技能 |
|--------------|------------|
| 提测、写验收单、补单测 / Compose 测试 | `android-qa` |
| 改完了，问能不能合进主分支 | `android-review` |

### 发布

| 你现在的情况 | 用这个技能 |
|--------------|------------|
| 打正式包、升版本号、混淆、写商店更新说明 | `android-ship` |

### 路由

| 你现在的情况 | 用这个技能 |
|--------------|------------|
| 一句话里有好几件事，或不知道选哪个 | `android-gstack` |

容易搞混的三点：

- **设计 vs 调界面**：先出 HTML / 看参考图 → `android-design`；改已有 Kotlin 界面 → `android-ui`。  
- **建工程 vs 写业务**：从零生成模板 → `android-project-scaffold`；在已有工程上写功能 → `android-feature`。  
- **验收**：`android-qa` 会尽量补自动化；真机权限弹窗、厂商差异仍要你自己点。Agent 不能假装已经点过真机。  
- **跨对话**：不要只靠聊天记忆；看 `projects/<项目名>/docs/HANDOFF.md`，或说「继续 projects/xxx」。

---

## 技能一览

| 分组 | 技能名 | 做什么 |
|------|--------|--------|
| 路由 | `android-gstack` | 分诊，不直接写业务 |
| 产品 | `android-spec` | 定范围、权限与商店风险、列出不做的事 |
| 设计 | `android-design` | 参考图 → 单个 HTML 多屏预览 |
| 开发 | `android-project-scaffold` | 在 `projects/` 下落盘可编译工程 |
| 开发 | `android-data-layer` | 网络 / Room / Repository |
| 开发 | `android-feature` | 功能实现（含页面写法） |
| 开发 | `android-ui` | 已有 Compose 的观感打磨 |
| 开发 | `android-investigate` | 查崩溃等原因；可冻结目录 |
| 质量 | `android-qa` | 验收单 + 尽量补自动化 |
| 质量 | `android-review` | 合入前检查 |
| 发布 | `android-ship` | 版本、渠道、混淆、提审清单 |

---

## 规则与门禁（Hook）

| 规则文件 | 作用 |
|----------|------|
| `.cursor/rules/android-core.mdc` | 核心家规与路由（始终生效） |
| `.cursor/rules/kotlin-compose.mdc` | 改 `.kt` / `.kts` 时的写法 |
| `.cursor/rules/android-gradle.mdc` | Gradle Catalog 与模块依赖 |
| `.cursor/rules/android-commercial.mdc` | 隐私、渠道、变现（始终生效） |
| `.cursor/rules/android-security.mdc` | 清单 / 签名 / 日志红线 |
| `.cursor/rules/cursor_reply.mdc` | 对你说话用大白话 |

| 门禁脚本 | 作用 |
|----------|------|
| `protect_android_secrets.py` | 拦密钥库读取和公网外带 |
| `check_android_projects_root.py` | 强制业务文件写在 `projects/` |
| `check_android_freeze.py` | 冻结目录后禁止改范围外文件 |
| `after_android_sensitive_edit.py` | 改 Manifest 等之后提醒自检 |

配置在 `.cursor/hooks.json`。脚本说明见 `.cursor/hooks/README.md`。  
冻结范围写在：`.cursor/state/freeze-dir.txt`。  
接力协议：`.cursor/handoff-protocol.md`；模板：`.cursor/handoff-templates/`。

---

## 项目备注（按你的 App 填写）

- 应用所在目录（如 `projects/xxx`）：
- 包名根：
- 依赖注入（Hilt / 其他）：
- minSdk / targetSdk：
- 上架渠道：
- 崩溃收集平台：
- 如何运行：
- Gradle Wrapper 备份：`projects/backup/` 下的 `gradle-wrapper.jar`、`gradlew`、`gradlew.bat`（脚手架强制从此复制）

---

## 刻意不做

- 不代替你在真机上点击、在商店后台提交、做法务签字。  
- 不把签名库、keystore 密码、生产环境 `google-services.json` 写进仓库或对话。  
- 不做内网穿透，也不把日志/源码传到公网粘贴站。  
- 不把 HTML 原型当成已经过审的商店设计定稿。
