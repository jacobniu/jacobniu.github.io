# AGENTS.md — 移动应用（Cursor）

本仓库技能包面向 **Kotlin + Jetpack Compose** 的安卓商业应用日常研发。  
先看「我该喊谁」，不会选就说 `android-gstack`。

## 我该喊谁（按你现在的处境）

| 你现在这样 | 用这个技能 |
|------------|------------|
| 还没想清楚做什么、要不要登录/支付/权限、先别写代码 | `android-spec` |
| 要写页面、改逻辑、原因已经清楚的 bug | `android-feature` |
| 能用但不好看、对设计稿、刘海/大字号/暗色 | `android-ui` |
| 闪退、ANR、偶现、线上只有一台机器复现、先查原因 | `android-investigate` |
| 提测、写真机点哪里、补单测/Compose 测 | `android-qa` |
| 改完了，问能不能合 | `android-review` |
| 打正式包、升 versionCode、写商店更新说明 | `android-ship` |
| 一句话里有好几件事，或不知道选哪个 | `android-gstack` |

容易混：

- 「登录页不好看」→ `android-ui`；「登录总失败 / 闪退」→ `android-investigate` 或 `android-feature`。
- 「帮我看看这波改动」→ `android-review`；「帮我改完再看看」→ 先 feature 再 review。

也可以直接说人话（「加一个设置页」「准备上架」），或点名技能。

## 技能一览

| 技能 | 干什么 |
|------|--------|
| `android-gstack` | 总路由，只分诊不写业务 |
| `android-spec` | 定范围、权限与商店风险、不做清单 |
| `android-feature` | 按现有架构写功能 |
| `android-ui` | 只打磨界面 |
| `android-investigate` | 故障根因，先调查后改 |
| `android-qa` | 真机验收单 + 能补的自动化 |
| `android-review` | 合入前审查 |
| `android-ship` | 版本、渠道、提审清单 |

## 规则（自动生效）

| 规则文件 | 作用 |
|----------|------|
| `.cursor/rules/android-core.mdc` | 架构、真机环境、改动边界（始终） |
| `.cursor/rules/kotlin-compose.mdc` | 编辑 `.kt` / `.kts` 时的规范 |
| `.cursor/rules/android-commercial.mdc` | 隐私、权限、渠道商店、变现（始终） |

## 项目备注（随应用填写）

- 应用模块：
- 包名根：
- DI：
- minSdk / targetSdk：
- 上架：Play / 国内渠道：
- 崩溃平台：
- 如何运行：

## 刻意不做

- 不包含 Hook、MCP。
- 不替代真机点击、商店后台提交、法务签字。
