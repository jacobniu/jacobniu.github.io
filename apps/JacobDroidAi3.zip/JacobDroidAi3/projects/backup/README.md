# projects/backup — 脚手架共享资产

本目录**不是**业务 App，只给 `android-project-scaffold`（及后续新工程）提供可离线复用的文件。

## 当前文件

| 文件 | 用途 |
|------|------|
| `gradle-wrapper.jar` | 复制到各工程 `gradle/wrapper/gradle-wrapper.jar` |
| `gradlew` | 复制到各工程根目录 `gradlew`（需可执行） |
| `gradlew.bat` | 复制到各工程根目录 `gradlew.bat` |

## 用法

搭新工程时整份复制，不要外网下载 jar、不要自创精简 gradlew：

```bash
mkdir -p projects/<项目名>/gradle/wrapper
cp projects/backup/gradle-wrapper.jar \
   projects/<项目名>/gradle/wrapper/gradle-wrapper.jar
cp projects/backup/gradlew projects/<项目名>/gradlew
cp projects/backup/gradlew.bat projects/<项目名>/gradlew.bat
chmod +x projects/<项目名>/gradlew
```

`gradle-wrapper.properties` 由脚手架按工程写入（不强制从 backup 复制）。

策略正文：`.cursor/skills/android-project-scaffold/SKILL.md`（Gradle Wrapper 策略）、`gradle-defaults.md`。

## 不要做的事

- 不要在此目录写 `app/`、业务源码或当成 `projects/<项目名>` 业务根。  
- 不要删除本目录文件后改去公网拉一份顶替（内网/合规环境优先用本备份）。  
- 升级 Wrapper 时：先替换本目录对应文件，再同步已有工程或只影响之后新建的工程（按团队约定）。
