# 工程骨架 SCAFFOLD

- project: `todo`
- root: `projects/todo/`
- updated: `2026-09-30`
- preset: demo-single

## 标识

- applicationId：`com.jacob.todo`
- 包名根：`com.jacob.todo`
- minSdk / targetSdk：`26` / `35`（compileSdk 35）

## 模块

- 仅 `:app`（demo-single）。Compose + Hilt + Navigation + DataStore 已进 Catalog；Room/Retrofit alias 已预留，本轮未接到 `:app`（留给 data-layer / feature）。

## 入口

- Application：`com.jacob.todo.App`（`@HiltAndroidApp`）
- Activity：`com.jacob.todo.MainActivity`（`@AndroidEntryPoint`）
- 导航宿主：`com.jacob.todo.navigation.AppNavHost`（空壳 Home，无假列表）
- 主题：暗色，主色对齐 DESIGN `#3399FF`

## 如何运行

```bash
cd projects/todo
chmod +x gradlew
./gradlew :app:assembleDebug
```

Android Studio 打开：`projects/todo/`（不要打开技能包根目录）。

`gradle-wrapper.jar`、`gradlew`、`gradlew.bat` 已从 `projects/backup/` 复制到本工程。

## 组装结果

- **jar 已就位**（来自 backup）；Agent 侧此前因 hook/`python` 问题未验证 `assembleDebug`，请本机或 Android Studio 再跑一次确认。

## 建议下一步技能

- 接 Room 本地待办库 → `android-data-layer`
- 或直接按 DESIGN 写列表/编辑页（含持久化）→ `android-feature`
