# Handoff 索引

- project: `todo`
- root: `projects/todo/`
- last_skill: `android-project-scaffold`
- last_status: `DONE_WITH_CONCERNS`
- suggested_next: `android-feature`
- updated: `2026-09-30`

## 产物一览

| 产物 | 路径 | 状态 | 备注 |
|------|------|------|------|
| SPEC | docs/SPEC.md | present | agreed；纯免费、仅内测、纯本地无提醒无登录 |
| DESIGN | docs/DESIGN.md | present | ready_for_dev；闹钟暗色风格 HTML |
| SCAFFOLD | docs/SCAFFOLD.md | present | demo-single；wrapper jar + gradlew/bat 已从 backup 复制 |
| DATA | docs/DATA.md | missing | |
| FEATURE | docs/FEATURE.md | missing | |
| QA | docs/QA.md | missing | |
| REVIEW | docs/REVIEW.md | missing | |
| SHIP | docs/SHIP.md | missing | |
| INVESTIGATE | docs/INVESTIGATE.md | missing | |

状态填：`present` / `missing` / `stale`（过时待更新）。

## 未收口 / 风险

- `assembleDebug` 仍建议本机再跑一遍确认
- applicationId 默认 `com.jacob.todo`（未另指定）

## 下一对话怎么接

用 Agent 模式打开本仓库，可说：

`android-gstack：继续 projects/todo，先读 docs/HANDOFF.md`

或：`android-feature：按 SPEC + DESIGN 实现待办列表与编辑`
