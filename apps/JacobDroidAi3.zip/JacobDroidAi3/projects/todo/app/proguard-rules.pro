# Keep empty for scaffold; android-ship will enable minify + rules later.
