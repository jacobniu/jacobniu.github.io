package com.jacob.todo.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val DarkColorScheme = darkColorScheme(
    primary = AccentBlue,
    onPrimary = TextPrimary,
    background = ScreenBlack,
    onBackground = TextPrimary,
    surface = CardDark,
    onSurface = TextPrimary,
    onSurfaceVariant = TextSecondary,
    outline = TextDimmed,
)

/** Dark-only theme aligned with DESIGN.md (alarm-style TODO). */
@Composable
fun TodoTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content,
    )
}
