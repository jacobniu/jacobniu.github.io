package com.jacob.todo.ui.theme

import androidx.compose.ui.graphics.Color

val AccentBlue = Color(0xFF3399FF)
val ScreenBlack = Color(0xFF000000)
val CardDark = Color(0xFF1C1C1E)
val TextPrimary = Color(0xFFFFFFFF)
val TextSecondary = Color(0xFF8E8E93)
val TextDimmed = Color(0xFF636366)
